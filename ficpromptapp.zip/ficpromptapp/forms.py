from django import forms
from chained_selects.widgets import ChainedSelectWidget
import language

class CKPromptForm(forms.Form):
    name = forms.CharField(
        required=True,
        label='Name')
    startingweight = forms.IntegerField(
        required=True,
        label='Starting Weight')

class bCKPromptForm(forms.Form):
    name = forms.CharField(
        required=True,
        label='Name')
    startingweight = forms.IntegerField(
        required=True,
        label='Starting Weight')
    formofaddress = forms.ChoiceField(
        required=True,
        label='',
        choices=(
            ('HE','he'),
            ('SHE','she'),
            ('THEY','they'),
            )
        )


pronounchoices = [(k, k.lower()) for k in language.PRONOUNS.keys()]
pronounchoices = sorted(pronounchoices, key=lambda k: k[0])

class FicPromptsForm(forms.Form):
    A_fname = forms.CharField(
        required=True,
        label='First Name')
    A_lname = forms.CharField(
        required=False,
        label='Last Name')
    A_pronoun = forms.ChoiceField(
        required=True,
        label='Pronoun',
        choices=pronounchoices,
    )

    B_fname = forms.CharField(
        required=True,
        label='First Name')
    B_lname = forms.CharField(
        required=False,
        label='Last Name')
    B_pronoun = forms.ChoiceField(
        required=True,
        label='Pronoun',
        choices=pronounchoices,
    )

    pkplot = forms.IntegerField(
        required=False,
        label = 'plot pk=',
    )
    pkplotline = forms.IntegerField(
        required=False,
        label = 'plotline pk=',
    )
    pksetting = forms.IntegerField(
        required=False,
        label = 'setting pk=',
    )

class ChubbyPromptsForm(forms.Form):
    A_fname = forms.CharField(
        required=True,
        label='First Name')
    A_lname = forms.CharField(
        required=False,
        label='Last Name')
    A_startweight = forms.IntegerField(
        required=False,
        label='Starting Weight (lb)')
    A_pronoun = forms.ChoiceField(
        required=True,
        label='Pronoun',
        choices=pronounchoices,
    )
    A_gainer = forms.BooleanField(
        required = False,
        label = 'Chubby',
        # initial = True,
        )

    B_fname = forms.CharField(
        required=True,
        label='First Name')
    B_lname = forms.CharField(
        required=False,
        label='Last Name')
    B_startweight = forms.IntegerField(
        required=False,
        label='Starting Weight (lb)')
    B_pronoun = forms.ChoiceField(
        required=True,
        label='Pronoun',
        choices=pronounchoices,
    )
    B_gainer = forms.BooleanField(
        required = False,
        label='Chubby'
        # initial = False, #initial resets every time page refreshed
        )

    pkwgplot = forms.IntegerField(
        required=False,
        label = 'wgplot pk=',
    )

    pkwgcause = forms.IntegerField(
        required=False,
        label = 'wgcause pk=',
    )

    pkwgrandom = forms.IntegerField(
        required=False,
        label = 'wgrandom pk=',
    )

    def clean(self):
        formdata = self.cleaned_data

        #ensure there is a gainer
        if not formdata['A_gainer'] and not formdata['B_gainer']:
            self._errors['A_gainer'] = 'At least one character needs to be chubby.'
            self._errors['B_gainer'] = 'At least one character needs to be chubby.'

        #if gainer, needs startweight
        if formdata['A_gainer'] and not formdata['A_startweight']:
            self._errors['A_startweight'] = 'Chubby characters require weight.'

        if formdata['B_gainer'] and not formdata['B_startweight']:
            self._errors['B_startweight'] = 'Chubby characters require weight.'


        return formdata
