import random
import re
# import bisect

from django.db.models import Q

import appsettings
import prompt
import randomhelper
import prompthelper
from ficpromptapp.models import Universe, Setting, Plotline, Plot, TagType, Tag, RelationshipStatus, Synonym, RoleSelection

#BETA
import ficpromptstextreplacementbeta as textreplacement


#-------------------------------------------------
#   GETPROMPT
#-------------------------------------------------

def getprompt(characters, pkplot, pkplotline, pksetting, chubby = False):
    prompt.resetprompt()

    # add chubby to prompt
    prompt.chubby = chubby
    prompt.log('chubbyprompt = ', prompt.chubby)

    #CHARACTERS
    # characters contains: {'characternumber': '1', 'pronoun': 'HE', 'fname': 'firstname', 'lname': 'lastname'}
    setcharacters(characters)
    prompt.log(
        '1=', prompt.characters[0]['fname'], prompt.characters[0]['lname'],
        '2=', prompt.characters[1]['fname'], prompt.characters[1]['lname'],
    )

    # FLUFF/ANGST (starting)
    # get initial fluff/angst by random weight
    setfluffangst()

    # PLOT/PLOTLINE/SETTING/UNIVERSE
    setpromptdebugobject(pkplot, pkplotline, pksetting)
    promptobjectsassigned = setpromptobjects()

    # failed to get all objects
    if not promptobjectsassigned:
        return prompt.prompt

    # FLUFF/ANGST (narrowed)
    setfluffangstbyprompt()
    prompt.log('fluff=',prompt.fluff,'| angst=',prompt.angst)

    # CHARACTER CHUBBY/NOT CHUBBY
    if prompt.chubby:
        setchubbycharacters()
    prompt.log('character1 chubby=', prompt.characters[0]['chubby'])
    prompt.log('character2 chubby=', prompt.characters[1]['chubby'])

    # RELATIONSHIPSTATUS
    # based on plot chosen; prior to tags
    setrelationshipstatus()
    prompt.log('relationship status=', prompt.relationshipstatus)


    # ROLES
    # needs to be done before setstaticoptionsreplacementlist() so can have [1ROLE], and after setcharacters()
    setroles()
    prompt.log('[1] role:', prompt.characters[0]['role'], '; required=', prompt.characters[0]['roleisrequired'])
    prompt.log('[2] role:', prompt.characters[1]['role'], '; required=', prompt.characters[1]['roleisrequired'])


    # STATIC OPTIONS
    setstaticoptionsreplacementlist()

    # TEXT
    text = getprompttext()

    # TAGS
    tagtexts = gettagtexts()


    # PROMPT
    prompt.prompt['text'] = text
    prompt.prompt['tags'] = tagtexts

    return prompt.prompt


def setchubbycharacters():
    """ If prompt chubby = True
        **Currently using plot only, not character options in request**
        Looks at plot and sets characters as chubby/not chubby
        depending on chubby_char1 and chubby_char2 in Plot object """

    prompt.characters[0]['chubby'] = False
    prompt.characters[1]['chubby'] = False

    prompt.log('prompt.plot.chubby_char1', prompt.plot.chubby_char1)
    prompt.log('prompt.plot.chubby_char2', prompt.plot.chubby_char2)
    prompt.log('prompt.plot.chubby_char1 is not never', (prompt.plot.chubby_char1 != "NEVER"))

    if prompt.plot.chubby_char1 == 'ALWAYS':
        prompt.log('[1]=always chubby')
        prompt.characters[0]['chubby'] = True

    if prompt.plot.chubby_char2 == 'ALWAYS':
        prompt.log('[2]=always chubby')
        prompt.characters[1]['chubby'] = True

    # one character must be chubby
    if not prompt.characters[0]['chubby'] and not prompt.characters[1]['chubby']:
        prompt.log('neither character has to be chubby')
        if prompt.plot.chubby_char1 == 'NEVER':
            prompt.log('making [2] chubby')
            prompt.characters[1]['chubby'] = True
        elif prompt.plot.chubby_char2 == 'NEVER':
            prompt.log('making [1] chubby')
            prompt.characters[0]['chubby'] = True
        else:
            charnum = random.randint(0,1)
            prompt.log('randomly making [' + str(charnum + 1) + '] chubby')
            prompt.characters[charnum]['chubby'] = True

    # select mutual

    if random.random() < appsettings.CHANCE_SECOND_CHUBBY_CHARACTER:
        prompt.log('setting second chubby character')
        if prompt.characters[0]['chubby'] and (prompt.plot.chubby_char2 != 'NEVER'):
            prompt.log('making [2] also chubby')
            prompt.characters[1]['chubby'] = True
        elif prompt.characters[1]['chubby'] and (prompt.plot.chubby_char1 != 'NEVER'):
            prompt.log('making [1] also chubby')
            prompt.characters[0]['chubby'] = True

    return



def getprompttext():
    """ Gets prompt text from plot
        Using static options (must be set prior) and dynamic options replacement
        Returns text """

    text = textreplacement.chooseline(prompt.plot.text, divider = '#')
    text = maketextreplacements(text, createparagraphs = True)

    # text = loopreplacesynonyms(text)
    # text = textreplacement.replaceoptionsandchoices(text)
    # text = loopreplacesynonyms(text)
    # text = textreplacement.replaceoptionsandchoices(text)
    # text = textreplacement.createparagraphs(text)
    # text = textreplacement.removeduplicatepunctuation(text)

    return text

#-------------------------------------------------
#   GET OBJECTS
#-------------------------------------------------

def setpromptobjects():
    """ Loops over getnextpromptobject() to obtain
        universe/setting/plotline/plot
        Can be used if object specified prior (from getpromptdebugobject)
        or if no objects exist (usual case)
        Returns True if successful, False if unable to find prompt """

    for j in range(5):
        for i in range(4):
            getnextpromptobject()
        if prompt.universe and prompt.setting and prompt.plotline and prompt.plot:
            success = True
            break

    if not prompt.universe or not prompt.setting or not prompt.plotline or not prompt.plot:
        msg = 'unable to find working prompt'
        prompt.prompt['text'] = msg
        prompt.log(msg)
        success = False

    prompt.log(
        'universe=', prompt.universe, '/',
        'setting=', prompt.setting, '/',
        'plotline=', prompt.plotline,
    )

    prompt.log('plot=', prompt.plot)

    return success



def setpromptdebugobject(pkplot = None, pkplotline = None, pksetting = None):
    """ Start with plot/plotline/setting in admin (pk given in url)
        Assigns to prompt
        If none are specified, quickly skips over and returns
        Returns none """

    if pkplot:
        try:
            prompt.plot = Plot.objects.get(pk=pkplot)
            setcompatiblefluffangst(prompt.plot)
        except:
            prompt.log('pkplot=', pkplot, 'does not exist')
            return prompt.prompt
    elif pkplotline:
        try:
            prompt.plotline = Plotline.objects.get(pk=pkplotline)
            setcompatiblefluffangst(prompt.plotline)
        except:
            prompt.log('pkplotline=', pkplotline, 'does not exist')
            return prompt.prompt
    elif pksetting:
        try:
            prompt.setting = Setting.objects.get(pk=pksetting)
            setcompatiblefluffangst(prompt.setting)
        except:
            prompt.log('pksetting=', pksetting, 'does not exist')
            return prompt.prompt

    return

def getnextpromptobject():
    """ Finds unassigned objects in prompt
        then assigns them from top to bottom (universe->plot).
        Downward, assigns by plotline/setting/universe attributes (inclusively),
        upward, assigns by attributes (exclusively).
        Chooses randomly by freq (may be adjusted), fluff/angst from potentials in list,
        then assigns directly to prompt.
        Only does one at a time, so need to call multiple times
        (eg in a loop) to get all.
        Possible to fail to get object (especially if have lower object assigned
        as still starts from top).
        """

    objdict = [
        {'classname': 'Universe', 'attrname': 'universes', 'obj': prompt.universe, 'reassignweights': False,},
        {'classname': 'Setting', 'attrname': 'settings', 'obj': prompt.setting, 'reassignweights': False,},
        {'classname': 'Plotline', 'attrname': 'plotlines', 'obj': prompt.plotline, 'reassignweights': True,},
        {'classname': 'Plot', 'attrname': '', 'obj': prompt.plot, 'reassignweights': True,},
    ]

    if all(o['obj'] for o in objdict):
        # prompt.log('getnextpromptobject(): all objects assigned')
        return False

    # get next objtype
    # start at top (universe) then go down, even if have lower obj
    for i, objtype in enumerate(objdict):
        if not objtype['obj']:
            nextobjtype = i
            break

    # prompt.log('_____________________________________')
    # prompt.log('nextobjtype', objdict[nextobjtype]['classname'])
    # prompt.log('------------------------------------')

    extantobjs = [o for o in objdict if o['obj']]

    objlist = []
    objweightadjustments = []
    containsdependentattributes = False

    # iterate through all active objects of nextobjtype
    # check if higher objects in obj; ex. for setting, check if universe is in setting.universes
    # inclusive; if no higher objects in obj, then can apply to any
    potentialobjs = eval(objdict[nextobjtype]['classname']).objects.filter(active=True)
    if not prompt.chubby:
        try:
            # will only work if plot object (others don't have chubbyprompt attribute)
            potentialobjs = potentialobjs.filter(chubbyprompt = False)
        except:
            pass

    for obj in potentialobjs:
        # prompt.log('evaluating', obj, '...')
        containsdependentattributes = False
        appendobj = False

        for _, objtype in enumerate(extantobjs):

            try:
                # get all attribute objects (i.e. nextobjtype = Setting, objtype = universe, get setting.universes)
                attrobjlist = getattr(obj, objtype['attrname']).all()
                # prompt.log('higher attribute:', objtype['attrname'], attrobjlist)
            except:
                attrobjlist = None

            if attrobjlist:
                containsdependentattributes = True
                if objtype['obj'] in attrobjlist:
                    # prompt.log("objtype['obj'] in attrobjlist = True")
                    # prompt.log('contains higher attribute, ADDING')
                    appendobj = True
                    break
                else:
                    # prompt.log('does not contain correct higher attribute, skipping')
                    pass

        if not containsdependentattributes:
            # prompt.log('no dependent attributes, adding')
            appendobj = True

        if appendobj:
            if objdict[nextobjtype]['reassignweights']:
                objlist, objweightadjustments = appendobjectwithweightadjustment(objlist, objweightadjustments, obj)
            else:
                objlist.append(obj)

    # prompt.log('---------')

    # if obj is contained as an attribute in other objects (i.e. setting contained in plot.settings), then
    # check if other objs contain nextobj as higher attribute
    # (exclusive, remove if not compatible)
    if objdict[nextobjtype]['attrname']:
        # do as statement so can alter objlist without messing up for loop
        for i, obj in enumerate(objlist):
            attrobjlist = None
            for _, objtype in enumerate(extantobjs):
                # check if obj is in lower objects; ex. for setting, check if setting is in plotline.settings
                try:
                    attrobjlist = getattr(objtype['obj'], objdict[nextobjtype]['attrname']).all()
                    # prompt.log(objtype['obj'], 'has attribute', objdict[nextobjtype]['attrname'], ':', attrobjlist)
                except:
                    attrobjlist = None
                    # prompt.log(objtype['obj'], 'does not have attribute', objdict[nextobjtype]['attrname'])

            if attrobjlist:
                if obj not in attrobjlist:
                    # prompt.log(obj, 'not in attrobjlist, REMOVING')
                    objlist[i] = None
                    try:
                        objweightadjustments[i] = None
                    except:
                        pass

    # prompt.log('---------')

    # prompt.log('objlist:', ', '.join([str(o) for o in objlist if o]))

    objlist = [o for o in objlist if o]
    objweightadjustments = [o for o in objweightadjustments if o]

    # prompt.log('objlist:', ', '.join([str(o) for o in objlist]))
    # prompt.log('objweightadjustments', ', '.join([str(i) for i in objweightadjustments]))

    nextobj = getrandomobjectbyfluffangst(objlist, adjustedweights = objweightadjustments)

    # prompt.log('CHOOSING', nextobj)

    # set prompt.object
    setattr(prompt, objdict[nextobjtype]['classname'].lower(), nextobj)

    return True



def appendobjectwithweightadjustment(objlist, objweightadjustments, obj):
    """ Assign obj higher priority if specific to universe/setting/plotline
        otherwise may get
        Returns objlist and objweightadjustments list
        to use in getrandomobjectbyfluffangst() """

    adjustment = 1.0

    try:
        if obj.universes.all():
            adjustment = appsettings.ADJUST_OBJ_FREQUENCY['UNIVERSE']
    except:
        pass

    try:
        if obj.settings.all():
            adjustment = appsettings.ADJUST_OBJ_FREQUENCY['SETTING']
    except:
        pass

    try:
        if obj.plotlines.all():
            adjustment = appsettings.ADJUST_OBJ_FREQUENCY['PLOTLINE']
    except:
        pass

    objlist.append(obj)
    objweightadjustments.append(adjustment)

    return objlist, objweightadjustments





#-------------------------------------------------
#   CHARACTERS/FLUFF/ANGST/RELATIONSHIP STATUS
#-------------------------------------------------

def setcharacters(characters):
    characters = assigncharacterorder(characters)
    prompt.characters = characters
    return True

def assigncharacterorder(characters):
    random.shuffle(characters)
    #assign numbers
    for i, character in enumerate(characters):
        character['characternumber'] = str(i+1) #i=0 but first character=1

    return characters

def setfluffangst():
    """ Randomly choose fluff and angst based on settings in appsettings
        Loops until at least one is True
        Assigns fluff and angst to prompt """

    fluff = False
    angst = False

    w = 0

    # loop ensures both aren't negative while keeping percentiles intact
    # simply doing ex. if not fluff, then angst=True, will favor one or the other
    while not fluff and not angst:
        if random.random() < appsettings.CHANCE_OF_FLUFF:
            fluff = True
        else:
            fluff = False

        if random.random() < appsettings.CHANCE_OF_ANGST:
            angst = True
        else:
            angst = False

        w = w + 1
        if w > 25:
            prompt.log('infinite loop: setfluffangst()')
            return True, True


    prompt.fluff = fluff
    prompt.angst = angst
    # prompt.log('fluff=', prompt.fluff, 'angst=', prompt.angst)

    return

def setfluffangstbyprompt():
    """ Choose fluff/angst compatible with plot/plotline/settings
        ex if all have angst, none have fluff, will only select tags based on angst
        Can only be called AFTER plot/plotline/setting objects chosen
        Sets prompt values directly, does not return any value """

    # angst/fluff choices: ANY, MUST_HAVE, CANNOT_HAVE
    fluffisflexible = (prompt.plot.fluff == 'ANY' and \
        prompt.plotline.fluff == 'ANY' and \
        prompt.setting.fluff == 'ANY')

    fluffisrequired = (prompt.plot.fluff == 'MUST_HAVE' or \
        prompt.plotline.fluff == 'MUST_HAVE' or \
        prompt.setting.fluff == 'MUST_HAVE')

    angstisflexible = (prompt.plot.angst == 'ANY' and \
        prompt.plotline.angst == 'ANY' and \
        prompt.setting.angst == 'ANY')

    angstisrequired = (prompt.plot.angst == 'MUST_HAVE' or \
        prompt.plotline.angst == 'MUST_HAVE' or \
        prompt.setting.angst == 'MUST_HAVE')

    if angstisrequired and fluffisflexible:
        prompt.fluff = False
    elif fluffisrequired and angstisflexible:
        prompt.angst = False
    # else use prior randomly chosen fluff/angst
    else:
        pass

    return

def setrelationshipstatus():
    """ Selects relationship status from plot statuses or random
        (other objects do not have a set relationship status)
        Assigns relationship status to prompt.relationshipstatus,
        Returns true """

    statuslist = prompt.plot.relationshipstatuses.all()

    # if plot does not specify relationship status can be any
    if not statuslist:
        statuslist = RelationshipStatus.objects.all()

    prompt.relationshipstatus = randomhelper.chooseobjectbyfrequency(statuslist)

    return True


#-------------------------------------------------
#   TAG FUNCTIONS
#-------------------------------------------------

def gettagtexts():
    """ Gets list of texts for tags
        First, creates tag dictionaries
        which contain 'tag' (object), 'type', 'text', 'required'
        'tag' = Tag object (optional)
        'type' = string:
            'PAIRING'
            'ROLE'
            'ALTERNATEUNIVERSE'
            'CHARACTERATTRIBUTE's
            'RELATIONSHIPSTATUS'
            'PROMPTFREEFORM'
            'TAGFREEFORM'
            # 'FLUFFANGST'
        'text' = string
        'required' = True/False
        Then processes text
        Returns final list of tagtexts in order
        (does not set prompt directly for ease of reading in main prompt function) """

    tags = []


    # PAIRING
    tags.append(getpairingtag())

    # ROLE
    tags.extend(getroletags())

    # RELATIONSHIPSTATUS
    tags.append(getrelationshipstatustag())

    # CHARACTERATTRIBUTE
    tags.extend(getcharacterattributetags())

    #PROMPTFREEFORM
    tags.extend(getpromptfreeformtags())

    #TAGFREEFORM
    tags.extend(gettagfreeformtags())

    #FLUFFANGST
    tags.append(getfluffangsttag())

    #CHUBBY
    # prompt.log('prompt.chubby', prompt.chubby)
    if prompt.chubby:
        tags.extend(getchubbycharactertags())
        # prompt.log('adding chubby character tags')
        # prompt.log(tags)


    # if tagtext if not assigned, that means that it is
    # from a textfield list of possible tagtexts
    # so need to get one randomly (weighted)
    # for tag in tags:
    #     # prompt.log('for tag in tags', tag)
    #     if tag['text'] == '':
    #         tag['text'] = gettagtext(tag)


    # sort tags by order in appsettings
    tags = sorted(tags, key=lambda t: gettagindex(t))

    # gets list of texts only, skips blank tags
    tagtexts = []

    for tag in tags:
        tagtextlist = gettagtextlist(tag)

        if tagtextlist:
            tagtexts.extend(tagtextlist)

    # put alternate universe right after pairing
    tagtexts = sorted(tagtexts, key=lambda t: gettagtextsort(t))
    tagtexts = [t.replace('Pairing:','') for t in tagtexts]


    # tagtexts = [gettagtext(t) for t in tags if t['text'] == '']
    # tagtexts = [tagtext for tagtext in tagtexts if tagtext != None]
    # tagtexts = [ for t in tagtexts]
    # tagtexts = [replacecharacternumber(t) for t in tagtexts]
    # prompt.log('tagtexts', tagtexts)

    return tagtexts

def gettagtextsort(t):
    # hardcode Pairing as first, AU as second, then the rest by prior sort method
    if 'Pairing:' in t:
        return 0
    elif 'Alternate Universe' in t:
        return 1
    else:
        return 2



def getroletags():
    tags = []

    if prompt.characters[0]['roleisrequired'] and prompt.characters[0]['role']:
        tags.append({
            'tag': None,
            'type': 'ROLE',
            'text': '*' + prompt.characters[0]['role'] + ' [1FULLNAME]',
            'required': True,
        })
    elif random.random() < appsettings.CHANCE_OF_ROLE_TAG and prompt.characters[0]['role']:
        tags.append({
            'tag': None,
            'type': 'ROLE',
            'text': prompt.characters[0]['role'] + ' [1FULLNAME]',
            'required': False,
        })

    if prompt.characters[1]['roleisrequired'] and prompt.characters[1]['role']:
        tags.append({
            'tag': None,
            'type': 'ROLE',
            'text': '*' + prompt.characters[1]['role'] + ' [2FULLNAME]',
            'required': True,
        })
    elif random.random() < appsettings.CHANCE_OF_ROLE_TAG and prompt.characters[1]['role']:
        tags.append({
            'tag': None,
            'type': 'ROLE',
            'text': prompt.characters[1]['role'] + ' [2FULLNAME]',
            'required': False,
        })

    return tags


def getchubbycharactertags():
    tags = []

    if prompt.characters[0]['chubby']:
        tags.append({
            'tag': None,
            'type': 'CHUBBYCHARACTER',
            'text': 'Chubby ' + prompt.characters[0]['fname'],
            'required': True,
        })
    if prompt.characters[1]['chubby']:
        tags.append({
            'tag': None,
            'type': 'CHUBBYCHARACTER',
            'text': 'Chubby ' + prompt.characters[1]['fname'],
            'required': True,
        })

    prompt.log('getchubbycharactertags() tags', tags)

    return tags




def gettagtextlist(tag, mintags = 1, maxtags = 1, returnasstring = False, keeprequired = False, donotdivide = False):
    """ Takes tag dict,
        Gets potential tags from textfield list 'tags'
        Use '||' for OR between tags
        Use '&&' to split into separate tags
        Return one of them based on randomoptiongenerator
        (to get weights, required etc) """

    text = ''

    prompt.log('-----------------')
    if not text:
        try:
            text = tag.tags
            prompt.log('tagtype', 'tag object')

        except:
            prompt.log('tag is not a tag object')

    if not text:
        try:
            if tag['text']:
                text = tag['text']
                prompt.log('tagtype', tag['type'])
        except:
            prompt.log('tag is not a tag dict')

    if not text:
        try:
            prompt.log('tagtype', tag['type'])
            text = tag['tag'].tags
        except:
            prompt.log('tag dict "tag" is not an object')

    prompt.log('possible tags', text)

    if not text:
        return []

    tagtextlist = textreplacement.getlistfromlines(text)



    # prompt.log('tagtextlist', tagtextlist)

    tagtextgenerator = textreplacement.randomoptiongenerator(
        tagtextlist,
        limitreuse = True,
        maxoptions = 10,
        keeprequiredmarker = True,
    )

    tagtexts = []
    numtags = 0

    # randomize maxtags
    maxtags = random.randint(1, maxtags)

    for tagtext in tagtextgenerator:
        # do not count required tags towards tag limit maxtags
        if '*' in tagtext:
            if not keeprequired:
                tagtext = tagtext.replace('*', '')
        else:
            numtags += 1

        if '||' in tagtext:
            tagtextlist = textreplacement.getlistfromlines(tagtext, divider = '||')
            prompt.log('tagtextlist if ||', tagtextlist)
            tagtextgenerator = textreplacement.randomoptiongenerator(
                tagtextlist,
                maxoptions = 1,
            )
            for text in tagtextgenerator:
                tagtext = text

        tagtext = maketextreplacements(tagtext, titlecase = True)

        # split into separate tags if contains &&
        # do not count extras towards maxtags
        if not donotdivide and '&&' in tagtext:
            tagtexts.extend(
                textreplacement.getlistfromlines(tagtext, divider = '&&')
            )
        else:
            tagtexts.append(tagtext)

        # prompt.log('tagtext', tagtext)

        if numtags >= maxtags:
            prompt.log('maxtags reached')
            break

    if returnasstring:
        s = "\r\n".join(tagtexts)
        return s

    # return list by default
    return tagtexts


# def gettagtext(tag):
#     tagtextgenerator = textreplacement.randomoptiongenerator(
#         textreplacement.getlistfromlines(tag['tag'].tags)
#     )

#     for tagtext in tagtextgenerator:
#         return tagtext

#     return tagtext


def getrelationshipstatustag():
    tag = {
        'tag': prompt.relationshipstatus,
        'type': 'RELATIONSHIPSTATUS',
        'text': '',
        'required': False,
    }

    return tag

def getcharacterattributetags():
    """
        do not need to choose by character
        (this is done later in gettagtexts -> replacecharacternumber())
        for [c] in tags textfield """

    tags = []

    for charnum in range(2):
        if random.random() < appsettings.CHANCE_OF_ATTRIBUTE:
            tag = getcharacterattributetag(charnum)
            tags.append(tag)
            if random.random() < appsettings.CHANCE_OF_SECOND_ATTRIBUTE:
                tag = getcharacterattributetag(charnum)
                if tag not in tags:
                    tags.append(tag)
    # prompt.log(tag)
    # prompt.log('getcharacterattributetags() - tags:', tags)

    return tags

def getcharacterattributetag(charnum):
    """ charnum = integer 0 or 1 """
    tagtype = TagType.objects.get(name = 'CHARACTERATTRIBUTE')
    objlist = Tag.objects.filter(tagtype = tagtype.pk, active = True)
    tagobj = getrandomobjectbyfluffangst(objlist)
    text = replacecharacternumber(tagobj.tags, characternumber = str(charnum + 1))

    tag = {
        'tag': tagobj,
        'type': 'CHARACTERATTRIBUTE',
        'text': text,
        'required': False,
    }

    return tag


def getpromptfreeformtags():
    tags = []
    tagtexts = []

    tagtexts.append(gettagtextlist(
        prompt.plot,
        mintags = 0,
        maxtags = appsettings.MAX_PLOT_TAGS,
        returnasstring = True,
        keeprequired = True,
        donotdivide = True,
    ))

    tagtexts.append(gettagtextlist(
        prompt.plotline,
        mintags = 0,
        maxtags = appsettings.MAX_PLOTLINE_TAGS,
        returnasstring = True,
        keeprequired = True,
        donotdivide = True,
    ))

    tagtexts.append(gettagtextlist(
        prompt.setting,
        mintags = 0,
        maxtags = appsettings.MAX_SETTING_TAGS,
        returnasstring = True,
        keeprequired = True,
        donotdivide = True,
    ))

    prompt.log('getpromptfreeformtags() tagtexts', tagtexts)

    # gets all tags from plot, plotline, setting - need to change this
    for tagtext in tagtexts:
        if tagtext:
            tags.append({
                'tag': None,
                'type': 'PROMPTFREEFORM',
                'text': tagtext,
                'required': False,
            })


    return tags




def gettagfreeformtags():
    tags = []
    tagtypes = TagType.objects.filter(freeform = True)
    if not prompt.chubby:
        tagtypes = tagtypes.exclude(name = 'CHUBBYPLOTDEVICE')

    for tagtype in tagtypes:
        # if has requiredplotfield and plot.requiredplotfield is not True,
        # then skip this tagtype (ie romance device, plot device)

        prompt.log('-------------')
        prompt.log('object tagtype', tagtype)

        if tagtype.requiredplotfield:
            if not getattr(prompt.plot, tagtype.requiredplotfield):
                prompt.log('requiredplotfield is false', tagtype.requiredplotfield)
                continue
            else:
                prompt.log('requiredplotfield is true', tagtype.requiredplotfield)
                pass

        # randomly determine number of tags of this type
        # determined by chanceoftagtype and chanceofsecondtagtype
        # (therefore can have 0, 1 or 2 tags of this type)
        numtags = 0
        if random.random() < tagtype.chanceoftagtype:
            numtags = 1
            if random.random() < tagtype.chanceofsecondtagtype:
                numtags = 2
        else:
            continue

        for i in range(numtags):
            tags.extend(gettagsbytagtype(tagtype = tagtype, maxtags = numtags))

    if not tags:
        prompt.log('no freeform tags!')
        return []

    finaltags = []
    totalfreeformtags = random.randint(0, appsettings.MAX_FREEFORM_TAGS)
    for i in range(totalfreeformtags):
        tag = random.choice(tags)
        if tag in finaltags:
            continue
        else:
            finaltags.append(tag)

    return finaltags

def gettagsbytagtype(tagtype = None, maxtags = 1):
    tags = []
    usedtags = []

    if not tagtype:
        return tags

    # filter on active, relationship status, universes, settings
    potentialtags = Tag.objects \
        .filter(active = True) \
        .filter(tagtype__pk = tagtype.pk) \
        .filter(Q(universes__in = [prompt.universe]) | \
            Q(universes = None)) \
        .filter(Q(settings__in = [prompt.setting]) | \
            Q(settings = None)) \
        .filter(Q(relationshipstatuses__in = [prompt.relationshipstatus]) | \
            Q(relationshipstatuses = None))

    if not prompt.chubby:
        potentialtags = potentialtags.exclude(chubbyprompt = True)

    if not potentialtags:
        return tags

    for i in range(maxtags):

        tag = getrandomobjectbyfluffangst(potentialtags)
        if not tag:
            return tags

        if tag in usedtags:
            continue

        tags.append({
            'tag': tag,
            'type': 'TAGFREEFORM',
            'text': '',
            'required': False,
        })

        usedtags.append(tag)

    prompt.log('freeform tags', tags)
    return tags

def getfluffangsttag():
    """ From prompts fluff/angst status,
        Selects basic fluff/angst tags
        Returns string"""

    if random.random() < appsettings.CHANCE_FLUFF_ANGST_TAG:
            return {
            'tag': None,
            'type': '',
            'text': '',
            'required': False,
        }

    if prompt.angst and prompt.fluff:
        tagtext = appsettings.FLUFF_AND_ANGST_TAGS
    elif prompt.fluff:
        tagtext = appsettings.FLUFF_ONLY_TAGS
    elif prompt.angst:
        tagtext = appsettings.ANGST_ONLY_TAGS

    tag = {
        'tag': None,
        'type': 'FLUFFANGST',
        'text': tagtext,
        'required': False,
    }

    return tag



# def getnexttag(tagtype):
#     """ Returns random tag object
#         matched by fluffangst """

#     potentialtags = [o for o in Tag.objects.filter(tagtype = tagtype.pk)]
#     # prompt.log('potentialtags', potentialtags)

#     tag = getrandomobjectbyfluffangst(potentialtags)

#     while tag:
#         potentialtags.remove(tag)
#         # prompt.log('tag', tag)

#         # tagtextlist = textreplacement.getlistfromlines(tag.tags)
#         # tagtext = gettagtext(tagtextlist)

#         # prompt.log('TAGS: getnexttag() yields:', tagtext)
#         yield tag
#         # yield gettagtext(tag.tags)

#         #see if there's another one
#         tag = getrandomobjectbyfluffangst(potentialtags)

#     return None



def getpairingtag():
    """ Takes characters from prompt,
        sorts in alphabetical order and makes pairing string
        (ex Jane Doe/John Doe)
        Returns tag dict """

    characters = prompt.characters

    characternames = [
        (character['fname'].strip() + ' ' + character ['lname'].strip()).strip() \
        for character in characters
    ]

    characternames = sorted(characternames)
    pairingtext = characternames[0] + '/' + characternames[1]

    # add 'Pairing:' for tagtext sorting purposes (end of function)

    tag = {
        'tag': None,
        'type': 'PAIRING',
        'text': 'Pairing:' + pairingtext,
        'required': True,
    }

    return tag




def gettagindex(tag):
    """ Given tag dict, finds integer index
        in appsettings.TAG_ORDER list
        Used in sorting tags by type for prompt display
        Returns integer
        (if tag['type'] not found, returns 100) """

    for i, tagtypename in enumerate(appsettings.TAG_ORDER):
        if tag['type'] == tagtypename:
            return i

    prompt.log('tag type not found: ', tag)
    return 100


def setroles():
    prompt.characters[0]['role'] = ''
    prompt.characters[0]['roleisrequired'] = False
    prompt.characters[1]['role'] = ''
    prompt.characters[1]['roleisrequired'] = False


    # get required roles
    if prompt.plot.requiredrole_char1:
        prompt.characters[0]['role'] = prompt.plot.requiredrole_char1
        prompt.characters[0]['roleisrequired'] = True
    if prompt.plot.requiredrole_char2:
        prompt.characters[1]['role'] = prompt.plot.requiredrole_char2
        prompt.characters[1]['roleisrequired'] = True

    # if both have required roles, stop here
    if prompt.characters[0]['role'] and prompt.characters[1]['role']:
        return

    # create generator from possible roles
    roletexts = ''
    roleslist = []
    getrolefromanysource = False

    # if no source selected, can get from anywhere
    if len(prompt.plot.roleselection.all()) == 0:
        getrolefromanysource = True

    # add possible source texts to string
    if getrolefromanysource or RoleSelection.objects.get(name = 'setting') in prompt.plot.roleselection.all():
        prompt.log('Can get role from setting')
        # downgrade setting roles
        roleslist.extend(
            adjustoptionpriority(
                textreplacement.getlistfromlines(prompt.setting.roles),
                downgrade = True
            )
        )
    if getrolefromanysource or RoleSelection.objects.get(name = 'plotline') in prompt.plot.roleselection.all():
        prompt.log('Can get role from plotline')
        roletexts += '\r\n' + prompt.plotline.roles
        # plotline is neutral
        roleslist.extend(
            textreplacement.getlistfromlines(prompt.plotline.roles),
        )
    if getrolefromanysource or RoleSelection.objects.get(name = 'plot') in prompt.plot.roleselection.all():
        prompt.log('Can get role from plot')
        # upgrade plot roles
        roleslist.extend(
            adjustoptionpriority(
                textreplacement.getlistfromlines(prompt.plot.roles),
                upgrade = True
            )
        )

    # if no roles, stop here
    if not roleslist:
        prompt.log('no roles found in roletexts')
        return

    # create random role generator from roletexts
    # this allows all required roles (*) to go together
    rolegenerator = textreplacement.randomoptiongenerator(
        roleslist,
        keeprequiredmarker = True,
    )

    for role in rolegenerator:
        if role:
            if not prompt.characters[0]['role']:
                if role[0] == '*':
                    prompt.characters[0]['role'] = role[1:]
                    prompt.characters[0]['roleisrequired'] = True
                else:
                    prompt.characters[0]['role'] = role
            elif not prompt.characters[1]['role']:
                if role[0] == '*':
                    prompt.characters[1]['role'] = role[1:]
                    prompt.characters[1]['roleisrequired'] = True
                else:
                    prompt.characters[1]['role'] = role
            else:
                # both characters have a role
                return
        else:
            prompt.log('no more roles found in generator')
            return

    return

def adjustoptionpriority(optionslist, upgrade = False, downgrade = False):
    """ Takes list to use in randomoptiongenerator
        and upgrades (ie - to neutral and neutral to +)
        or downgrades each item
        Leaves required (*) but does add +/- to it in case can be reused
        Returns adjusted list in same order as original """

    newoptionslist = []
    for option in optionslist:
        o = option
        if downgrade:
            if '+' in o:
                o = o.replace('+', '')
            elif not '-' in o:
                if '*' in o:
                    o = o.replace('*', '*-')
                else:
                    o = '-' + o
        if upgrade:
            if '-' in o:
                o = o.replace('-', '')
            elif not '+' in o:
                if '*' in o:
                    o = o.replace('*', '*+')
                else:
                    o = '+' + o
        newoptionslist.append(o)

    prompt.log('adjustoptionpriority optionslist=', optionslist)
    prompt.log('adjustoptionpriority newoptionslist=', newoptionslist)

    return newoptionslist




#-------------------------------------------------
#   HELPER FUNCTIONS
#-------------------------------------------------


def loopreplacesynonyms(text):
    text = textreplacement.loopreplacetext(
        text,
        textreplacement.replacesynonyms,
        Synonym = Synonym,
    )

    # prompt.log('loopreplacesynonyms() text=', text)

    return text


# (moved from ficpromptstextreplacementbeta.py)
def setstaticoptionsreplacementlist():
    """ Takes static option fields from plot object,
        names are returned from plot model object
        (currently optA/optB/optC)
        and selects one from each that will stay
        static throughout future text replacements
        in plot, tags, etc
        Replaces synonyms here so they will also be static
        Adds staticoptionsreplacementlist to prompt object
        Returns True"""

    optionfields = prompt.plot.getoptionfields()
    optionsreplacementlist = []

    for (option_field, option_markup) in optionfields['static']:
        optiontext = getattr(prompt.plot, option_field)
        optiontext = textreplacement.chooseline(optiontext)
        optiontext = loopreplacesynonyms(optiontext)

        optionsreplacementlist.append([option_markup, optiontext])

    prompt.staticoptionsreplacementlist = optionsreplacementlist

    return True


def getrandomobjectbyfluffangst(objlist, adjustedweights = None):
    """ Returns a random object from list [objlist]
        compatible with prompt's angst/fluff settings;
        All objects based off of model template can be used
        Plot uses adjust_frequencies and adjustedweights to balance frequency
        Returns obj """

    obj = None
    w = 0

    # doing this prior prevents infinite loop if no compatible objects exist
    # having adjust_frequencies, adjustedweights
    if not adjustedweights:
        objlist = [o for o in objlist if isfluffangstcompatible(o)]
        adjust_frequencies = False
    else:
        adjust_frequencies = True

    if not objlist:
        # prompt.log('getrandomobjectbyfluffangst - empty objlist')
        return None

    while not obj:
        obj = randomhelper.chooseobjectbyfrequency(objlist, adjust_frequencies, adjustedweights)

        # because objlist matches adjustedweights, cannot truncate objlist prior (as above)
        # so will check each object here
        if adjustedweights:
            if not isfluffangstcompatible(obj):
                obj = None
                # prompt.log('incompatible')

        w = w + 1
        if w > 25:
            prompt.log('infinite loop: getrandomobjectbyfluffangst()')
            return None

    return obj


def isfluffangstcompatible(obj):
    """ Determines if obj's fluff/angst settings are
        compatible with prompt's fluff/angst settings
        Returns True/False """

    # prompt.log(obj.name,': fluff',obj.fluff,'angst',obj.angst)
    # prompt.log('prompt:','fluff',prompt.fluff,'angst',prompt.angst)

    iscompatible = True

    # angst/fluff choices: ANY, MUST_HAVE, CANNOT_HAVE
    if obj.fluff == 'MUST_HAVE' and not prompt.fluff:
        iscompatible = False
    elif obj.fluff == 'CANNOT_HAVE' and prompt.fluff:
        iscompatible = False
    elif obj.angst == 'MUST_HAVE' and not prompt.angst:
        iscompatible = False
    elif obj.angst == 'CANNOT_HAVE' and prompt.angst:
        iscompatible = False

    return iscompatible


def setcompatiblefluffangst(obj):
    """ Loops until fluff/angst combination is compatible with object
        Used for debugging
        Returns False for infinite loop """
    w = 0
    while not isfluffangstcompatible(obj):
        setfluffangst()
        w = w + 1
        if w > 25:
            prompt.log('infinite loop "while not setcompatiblefluffangst()"')
            return False
    return True

def replacecharacternumber(text, characternumber = str(random.randint(1,2))):
    """ If pronoun is set to start with either character [c]
        then chooses 1 or 2
        (ie [cFULLNAME] = [1FULLNAME], [c] = [2])
        Returns text after replacement made """

    if not text:
        return ''

    text = text.replace('[c', '[' + characternumber)
    text = text.replace('{c |', '{' + characternumber + ' |')
    return text

def replacechubbycharacternumber(text):
    """ If pronoun is set to start with either character [chubby]
        then chooses 1 or 2
        (ie [chubbyFULLNAME] = [1FULLNAME], [chubby] = [2])
        Returns text after replacement made """

    if not text:
        return ''

    if prompt.characters[0]['chubby'] and prompt.characters[1]['chubby']:
        characternumber = str(random.randint(1,2))
    elif prompt.characters[0]['chubby']:
        characternumber = '1'
    else:
        characternumber = '2'

    text = text.replace('[chubby', '[' + characternumber)

    # so can have '[2] uses [1]'s tummy as a pillow'
    if characternumber == '1':
        text = text.replace('[c', '[2')
    else:
        text = text.replace('[c', '[1')


    # text = text.replace('{chubby |', '{' + characternumber + ' |')
    return text

def maketextreplacements(text, createparagraphs = False, titlecase = False):
    text = loopreplacesynonyms(text)
    if prompt.chubby:
        text = replacechubbycharacternumber(text)
    text = replacecharacternumber(text)
    text = textreplacement.replaceoptionsandchoices(text)

    text = loopreplacesynonyms(text)
    if prompt.chubby:
        text = replacechubbycharacternumber(text)
    text = replacecharacternumber(text)
    text = textreplacement.replaceoptionsandchoices(text)

    if titlecase:
        text = textreplacement.titlecase(text, maxwords = appsettings.MAX_TAG_WORDS_FOR_TITLECASE)

    if createparagraphs:
        text = textreplacement.createparagraphs(text)
        text = textreplacement.removeduplicatepunctuation(text)

    text = text.strip()

    return text
