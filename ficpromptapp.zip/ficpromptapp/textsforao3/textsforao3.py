from shutil import copyfile


# from cStringIO import StringIO

# TODO
# extend each
# add continuing ones to file

FILEPATH = '/home/htw/ficdb/ficdbapp/SYN_template/'
LASTCONVOFILE = FILEPATH + 'textmessages_last.txt'
GENERATEDLASTCONVOFILE = FILEPATH + 'textmessages_last_generated.txt'
NEWCONVOFILE = FILEPATH + 'textmessages.txt'
BACKUPCONVOFILE = FILEPATH + 'textmessages_backup.txt'
BACKUPGENERATEDCONVOFILE = FILEPATH + 'textmessages_last_generated_backup.txt'

START_MARKER = '[START]'
END_MARKER = '[END]'



LINE_START = '<pre>    '
LINE_END = '</pre>'
NEWLINE = '\r\n'

MAX_CHARS_SENT = 30
MAX_CHARS_REPLY = 30

MAX_LINES_LONG_CONVO = 25
MAX_LINES_SHORT_CONVO = 10
MIN_OLD_CONVO_LINES = 3

DIVIDER = '------------------------------------------'
CONVO_WIDTH = len(DIVIDER)

# RECIPIENT_NAME = '♥♥♥ YUURI!!! ♥♥♥'
RECIPIENT_NAME = 'Nikiforov, Victor'

# DRAFT_START = '----------------------------------------'
# DRAFT_CURSOR = '|'
# DRAFT_END = '----------------------------------------'

DATE_EMPHASIS = '--'

SENT_LINE1 = ' < '
SENT_LINE2= '  '

REPLY_LINE1 = ' > '
REPLY_LINE2 = '  '


READ_START = '(Read '
READ_START_CHARS = 13
READ_END = ')   '

# EXTRA
LINES_BEFORE_CONVOTEXT = 2
LINES_BEFORE_DATE = 2
LINES_BEFORE_CONVOLINE = 1
LINES_BEFORE_END = 1


def converttolines(text, maxchars, line1, line2, startonleft):
    lines = getlines(text, maxchars)

    if startonleft:
        newlines = [line1 + lines.pop(0)]
        newlines.extend([line2 + s for s in lines])
    else:
        newlines = [lines.pop(0) + line1]
        newlines.extend([s + line2 for s in lines])

    if not startonleft:
        newlines = [addspaces(line) for line in newlines]

    return newlines


def getlines(line, maxchars):
    lines = []
    s = line.strip()


    for i in range(25):
        if len(s) < maxchars:
            lines.append(s)
            break

        indexoflastspace = s.rfind(' ', 0, maxchars)
        lines.append(s[:indexoflastspace].strip())
        s = s[indexoflastspace:].strip()

    print('getlines()')
    print(lines)

    return lines


def addspaces(txt, addtoleft = True):
    if addtoleft:
        s = ''.join([' ' for x in range(CONVO_WIDTH - len(txt))]) + txt
    else:
        s = txt + ''.join([' ' for x in range(CONVO_WIDTH - len(txt))])
    return s




def createnewconvo():
    print('createnewconvo()')

    if getinput('short convo?', ['y','n']) == 'y':
        maxlines = MAX_LINES_SHORT_CONVO
    else:
        maxlines = MAX_LINES_LONG_CONVO

    # UNCOMMENT FOR NOT DEBUG
    # newconvodatetxt = input('new convo date (ex Thu, 11/03, 23:57):  ')
    # newconvosenttxt = input('new convo:  ')
    # newconvoreaddatetxt = input('read date (ex 11/07, 11:36):  ')
    # newconvoreplytxt = input('reply:  ')
    # newconvodrafttxt = input('draft text: ')

    # DEBUG ONLY
    # newconvodatetxt = 'Thu, 11/03, 23:57'
    # newconvosenttxt = 'At the Osaka airport. It feels wrong to be in Japan without you.'
    # newconvoreaddatetxt = '11/07, 11:36'
    # newconvoreplytxt = 'Would you mind maybe distracting Yakov for a couple hours?'
    # newconvodrafttxt = 'It feels wrong to be anywhere without you. No matter where you are. Or what youre doing.'

    if getinput('Use generated convo file?', ['y','n']) == 'y':
        oldconvofile = GENERATEDLASTCONVOFILE

    else:
        oldconvofile = LASTCONVOFILE

    with open(oldconvofile,'r') as file:
        oldconvotxt = file.read()

    # OLD CONVO
    oldlines = oldconvotxt.splitlines()

    # NEW CONVO
    newlines = []

    # add date
    # add sent line
    # add read line
    # add reply line
    # done
    # draft

    lastchoice = ''

    for _ in range(100):
        choice = getinput('add Date, Sent, Received (enter if done)', ['d','s','r', ''])
        if choice == '':
            break

        lastchoice = choice

        if choice == 'd':
            print('(ex Thu, 11/03, 23:57)')

        text = input('text:  ')
        text = text.strip()

        if choice == 'd':
            newlines.extend([''] * LINES_BEFORE_DATE)
            newlines.append(centerline(DATE_EMPHASIS + ' ' + text + ' ' + DATE_EMPHASIS))
        elif choice == 's':
            newlines.extend([''] * LINES_BEFORE_CONVOLINE)
            newlines.extend(converttolines(text, MAX_CHARS_SENT, SENT_LINE1, SENT_LINE2, startonleft = False))
        elif choice == 'r':
            newlines.extend([''] * LINES_BEFORE_CONVOLINE)
            newlines.extend(converttolines(text, MAX_CHARS_REPLY, REPLY_LINE1, REPLY_LINE2, startonleft = True))
        else:
            break

    if lastchoice == 's':
        print('')
        readdatetime = input('Read date/time? (ex 11/07, 11:36)  ')
        readdatetime = readdatetime.strip()
        if readdatetime:
            newlines.append(addspaces(READ_START + readdatetime + READ_END))






    # if newconvodatetxt:
    #     newlines.extend([''] * LINES_BEFORE_DATE)
    #     # newlines.extend(addblanklines(LINES_BEFORE_DATE))
    #     newlines.append(centerline(DATE_EMPHASIS + ' ' + newconvodatetxt + ' ' + DATE_EMPHASIS))
        # newlines.extend(addblanklines(LINES_BEFORE_CONVOTEXT))

    # if newconvosenttxt:
    #     newlines.extend([''] * LINES_BEFORE_CONVOLINE)
    #     # newlines.extend(addblanklines(LINES_BEFORE_CONVOLINE))
    #     newlines.extend(converttolines(newconvosenttxt, MAX_CHARS_SENT, SENT_LINE1, SENT_LINE2, startonleft = False))

    # if newconvoreaddatetxt:

    #     # newconvotxt ''.join([' ' for x in range(READ_START_CHARS)]) + READ_START + newconvoreaddatetxt + READ_END)
    #     newlines.append(addspaces(READ_START + newconvoreaddatetxt + READ_END))

    # if newconvoreplytxt:
    #     newlines.extend([''] * LINES_BEFORE_CONVOLINE)
    #     newlines.extend(converttolines(newconvoreplytxt, MAX_CHARS_REPLY, REPLY_LINE1, REPLY_LINE2, startonleft = True))


    numlinesoldconvo = len(oldlines)
    numlinesnewconvo = len(newlines)
    allowednumlinesoldconvo = 0

    if numlinesnewconvo >= maxlines:
        allowednumlinesoldconvo = MIN_OLD_CONVO_LINES
    else:
        allowednumlinesoldconvo = maxlines - numlinesnewconvo

    oldconvostartlinenumber = numlinesoldconvo - allowednumlinesoldconvo

    for i in range(25):
        try:
            if oldlines[oldconvostartlinenumber] == '':
                oldconvostartlinenumber = oldconvostartlinenumber - (i + 1)
            elif DATE_EMPHASIS in oldlines[oldconvostartlinenumber]:
                oldconvostartlinenumber = oldconvostartlinenumber + LINES_BEFORE_CONVOLINE + (i + 1)
            else:
                break
        except:
            print('oldconvostartlinenumber not working')
            break

    oldlinesshortened = oldlines[oldconvostartlinenumber:]

    # combine together
    convolines = []
    convolines.extend(oldlinesshortened)
    convolines.extend(newlines)

    # REMOVE READ
    convolines = removeread(convolines, keeplast = True)


    lines = []

    # START CONVO
    lines.append(DIVIDER)
    lines.append(centerline(RECIPIENT_NAME))
    lines.append(DIVIDER)

    # CONVO
    lines.extend(convolines)

    # END CONVO
    lines.append(DIVIDER)

    newconvodrafttxt = input('draft message:  ')

    lines.extend(converttolines(newconvodrafttxt, CONVO_WIDTH, ' ', ' ', startonleft = True))
    lines[len(lines)-1] += '|'
    lines.append(DIVIDER)


    unformattedconvotext = NEWLINE.join(oldlines + newlines)

    formattedlines = [LINE_START + line + LINE_END + NEWLINE for line in lines]
    formattedconvotext = ''.join(formattedlines)
    formattedconvotext = NEWLINE + NEWLINE + START_MARKER + NEWLINE + NEWLINE \
        + formattedconvotext \
        + NEWLINE + NEWLINE + END_MARKER + NEWLINE + NEWLINE


    # clear file
    filewritetype = getinput('write/append', ['w', 'a'])

    # make backup if overwriting
    if filewritetype == 'w':
        copyfile(NEWCONVOFILE, BACKUPCONVOFILE)



    # write new file
    with open(NEWCONVOFILE, filewritetype) as file:
        file.write(formattedconvotext)

    # write last convo file
    copyfile(GENERATEDLASTCONVOFILE, BACKUPGENERATEDCONVOFILE)

    with open(GENERATEDLASTCONVOFILE, 'w') as file:
        file.write(unformattedconvotext)




    print(NEWLINE.join(lines))
    print(formattedconvotext)

    return

def centerline(text):
    textlength = len(text)
    numberspaces = (CONVO_WIDTH - textlength)/2
    leftspaces = ''.join([' ' for x in range(int(numberspaces))])
    s = leftspaces + text
    return s

def addline(newline = ''):
    s = newline + NEWLINE
    return s

def addblanklines(n = 1):
    s = [NEWLINE for i in range(n)]
    return s

def removeread(lines, keeplast = True):
    newlines = [l for l in lines if READ_START not in l]
    if keeplast:
        lastline = lines[len(lines) - 1]
        if READ_START in lastline:
            newlines.append(lastline)

    return newlines


def getinput(q, correctanswers = []):
    print('')

    for _ in range(25):
        if correctanswers:
            a = input(q + '(' + ' / '.join(correctanswers) + ')' + '  ')
            if a in correctanswers:
                return a
        else:
            a = input(q + ':  ')
            return a

    print('no correct answers given')
    return ''






















