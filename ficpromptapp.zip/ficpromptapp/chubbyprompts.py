import random
import bisect
import copy
import re

from django.db.models import Q

import prompthelpers as h
import appsettings as settings
import prompt
import textreplacement

from ficpromptapp.models import WGPlot

def getprompt(characters,pkwgplot,pkwgcause,pkwgrandom):
    """ Takes user input from form/view,
    creates random prompt and returns prompt dictionary """

    prompt.resetprompt()

    characters = assigncharacterorder(characters)

    #get wgplot
    try:
        wgplot = WGPlot.objects.get(pk=pkwgplot)
    except WGPlot.DoesNotExist:
        prompt.prompt['text'] = 'ERROR: pkwgplot pk=' + str(pkwgplot) + ' does not exist'
        return prompt.prompt
    except ValueError:
        wgplot = getwgplot(characters)

    wgplot = copy.deepcopy(wgplot)

    if not wgplot:
        prompt.prompt['text'] = 'ERROR: unable to get plot'
        return prompt.prompt

    is_mutual = getismutual(wgplot, characters)
    is_establishedrelationship = getisestablishedrelationship(wgplot)
    is_intentional = getisintentional(wgplot)

    # do text replacements of wgplot early so can use result to filter addt'l plots
    wgplot = textreplacement.processprompttext(wgplot, characters)

    if h.randomtruefalse(percent=settings.CHANCE_WG_CAUSE_PLOT):
        #get wgcause
        try:
            wgcauseplot = WGPlot.objects.get(pk=pkwgcause)
        except WGPlot.DoesNotExist:
            prompt.prompt['text'] = 'ERROR: pkwgcause pk=' + str(pkwgplot) + ' does not exist'
            return prompt.prompt
        except ValueError:
            wgcauseplot = getwgcauseplot(wgplot, is_mutual, is_establishedrelationship, is_intentional)
    else:
        wgcauseplot = None


    if h.randomtruefalse(percent=settings.CHANCE_RANDOM_WG_PLOT):
        #get random plot
        try:
            wgrandomplot = WGPlot.objects.get(pk=pkwgrandom)
        except WGPlot.DoesNotExist:
            prompt.prompt['text'] = 'ERROR: wgrandom pk=' + str(pkwgrandom) + ' does not exist'
            return prompt.prompt
        except ValueError:
            wgrandomplot = getwgrandomplot(wgplot, is_mutual, is_establishedrelationship, is_intentional)
            try:
                if wgrandomplot.pk == wgcauseplot.pk:
                    wgrandomplot = None
            except AttributeError:
                pass
    else:
        wgrandomplot = None

    if wgcauseplot and wgrandomplot:
        if h.randomtruefalse(percent=settings.CHANCE_WG_CAUSE_VS_RANDOM_WG_PLOT):
            wgcauseplot = copy.deepcopy(wgcauseplot)
            wgrandomplot = None
        else:
            wgrandomplot = copy.deepcopy(wgrandomplot)
            wgcauseplot = None

    #format addt'l wgplot texts
    # wgplot = textreplacement.processprompttext(wgplot, characters)
    if wgcauseplot:
        wgcauseplot = textreplacement.processprompttext(wgcauseplot, characters)
    if wgrandomplot:
        wgrandomplot = textreplacement.processprompttext(wgrandomplot, characters)



    #get tags
    tags = selectwgtags(wgplot, wgcauseplot, characters, is_mutual, is_establishedrelationship, is_intentional, wgrandomplot=wgrandomplot)

    #create return prompt dictionary
    prompt.prompt['text'] = wgplot.text
    #prompt.prompt['tags'] = wgplot.freeform_tags + wgplot.cause_tags #temp!
    prompt.prompt['tags'] = tags

    #data for debugging
    prompt.prompt['wgplot'] = wgplot
    prompt.prompt['wgcause'] = wgcauseplot
    prompt.prompt['wgrandom'] = wgrandomplot

    return prompt.prompt







#-----------------------------------------------------

def getwgplot(characters):
    """ Returns wgplot as WGPlot object """

    canbemutual = bothgainers(characters)

    if canbemutual:
        wgplotlist = WGPlot.objects.filter(active=True)
    else:
        wgplotlist = WGPlot.objects.filter(active=True).exclude(is_mutual='YES')

    wgplotlist = [wgplot for wgplot in wgplotlist if wgplot.is_active() == True]

    weightedwgplotlist = list(zip(
        wgplotlist,
        map(lambda x: settings.PLOT_FREQUENCY[x.plot_frequency], wgplotlist)
    ))
    wgplot = weightedchoice(weightedwgplotlist)

    return wgplot


def getplotfrequencyweight(plot):

    if plot.plot_frequency == 'VERY_COMMON':
        f = settings.WEIGHT_VERYCOMMON_PLOT
    elif plot.plot_frequency == 'RARE':
        f = settings.WEIGHT_RARE_PLOT
    else:
        f = 1.0

    return f


def getwgcauseplot(wgplot, is_mutual, is_establishedrelationship, is_intentional):
    """ Returns wgcauseplot as WGPlot object """

    # prompt.log('wgplot.cause_and_effect',wgplot.cause_and_effect)
    prompt.log(str(wgplot),'wgplot.cause_and_effect=',wgplot.cause_and_effect)

    if wgplot.cause_and_effect == "EFFECT": #effect only - means can have cause
        wgcauselist = WGPlot.objects.exclude(cause_tags = '')
        wgcauseplot = findcompatibleplot(wgplot, wgcauselist, is_mutual, is_establishedrelationship, is_intentional)

        prompt.log('wgcauseplot',str(wgcauseplot))
    else:
        wgcauseplot = None
        prompt.log('prompt cannot have cause')

    return wgcauseplot

def getwgrandomplot(wgplot, is_mutual, is_establishedrelationship, is_intentional):
    wgrandomlist = WGPlot.objects.exclude(randomthings_tags = '')
    wgrandomplot = findcompatibleplot(
        wgplot,
        wgrandomlist,
        is_mutual,
        is_establishedrelationship,
        is_intentional,
        filtergaintype = True,
        filterrelationshiptype = False,
        filtermutualgain = True
    )
    return wgrandomplot


def findcompatibleplot(wgplot, plotlist, is_mutual = False, is_establishedrelationship = False, is_intentional = False, filtergaintype = True, filterrelationshiptype = True, filtermutualgain = True):

    #active only
    plotlist = plotlist.filter(active = True)

    #exclude self
    plotlist = plotlist.exclude(pk = wgplot.pk)

    #filter on gaintype
    if is_intentional:
        plotlist = plotlist.filter(gaintype_intentional = True)
    else:
        plotlist = plotlist.filter(gaintype_unintentional = True)

    # if filtergaintype:
    #     if not wgplot.gaintype_unintentional:
    #         plotlist = plotlist.exclude(gaintype_unintentional = True)
    #     if not wgplot.gaintype_intentional:
    #         plotlist = plotlist.exclude(gaintype_intentional = True)
    #     if not wgplot.gaintype_noweightgain:
    #         plotlist = plotlist.exclude(gaintype_noweightgain = True)

    if filterrelationshiptype:
        #filter on new/established relationship
        if is_establishedrelationship:
            plotlist = plotlist.exclude(type_of_relationship = 'NEW')
        else:
            plotlist = plotlist.exclude(type_of_relationship = 'ESTABLISHED')

    #filter on mutual wg
    if filtermutualgain:
        if is_mutual:
            plotlist = plotlist.filter(
                Q(is_mutual = 'YES') | Q(is_mutual = 'OPTIONAL')
            )
        else:
            plotlist = plotlist.filter(
                Q(is_mutual = 'NO') | Q(is_mutual = 'OPTIONAL')
            )

    # if wgplot contains specific numbers,
    # then do not allow specific numbers in compatible plot tags
    regexp_pounds = r'.*\d{2,3} pounds.*'
    regexp_weightmarkup = r'.*\[(?P<character>\d)?(\|)?(?P<weighttype>POUNDS|WEIGHT)\|(?P<gaintype>\w+)\|?(?P<roundtype>ROUND|EXACT)?\].*'
    p = re.compile(regexp_pounds, re.IGNORECASE)
    if p.search(wgplot.text):
        plotlist = plotlist.exclude(
            Q(cause_tags__iregex = regexp_weightmarkup) | Q(randomthings_tags__iregex = regexp_weightmarkup)
        )

    #debug specific numbers
    # testplotlist = plotlist.filter(
    #     Q(cause_tags__iregex = regexp_weightmarkup) | Q(cause_tags__iregex = regexp_weightmarkup)
    # )
    # prompt.log('prompt', wgplot.text)
    # for testplot in testplotlist:
    #     prompt.log('tags with specific numbers:', testplot.cause_tags, testplot.randomthings_tags)

    #choose newplot
    try:
        newplot = random.choice(plotlist)
    except IndexError:
        newplot = None
        prompt.log('findcompatibleplot(): no compatible plot found')

    return newplot



#-----------------------------------------------------


def selectwgtags(wgplot, wgcauseplot, characters, is_mutual, is_establishedrelationship, is_intentional,  wgrandomplot=None):
    """ Returns tags (list) """

    #tag is string
    #tags is [tag,tag,tag]
    workingtags = []

    workingtags.append(getpairingtag(characters))
    workingtags.extend(getchubbycharactertags(characters, is_mutual))
    workingtags.extend(getautomatictags(wgplot, characters, is_mutual, is_establishedrelationship, is_intentional))


    if wgcauseplot:
        workingtags.extend(gettagsfromplotattribute(wgcauseplot, 'cause_tags', maxtags=1))
    if wgrandomplot:
        workingtags.extend(gettagsfromplotattribute(wgrandomplot, 'randomthings_tags', maxtags=1))

    #these make more sense when they're last
    workingtags.extend(gettagsfromplotattribute(wgplot, 'freeform_tags', maxtags=2))

    # prompt.log('working tags', len(workingtags), workingtags)

    tags = []
    for tag in workingtags:
        tag = tag.strip()
        # paired tags (containing '&') are treated as one tag until now
        # then they are split so look like two tags when displayed
        if '&' in tag:
            tags.extend(t.strip() for t in tag.split('&'))
        elif tag == '': #remove empty tags
            pass
        else:
            tags.append(tag)

    # prompt.log('tags', len(tags), tags)

    tags = removeduplicatetags(tags)
    # prompt.log('tags after duplicates removed', len(tags), tags)

    return tags

def getautomatictags(wgplot, characters, is_mutual, is_establishedrelationship, is_intentional):
    """ Returns tags (list) """

    tags = []

    #wg type tags
    if not is_intentional and wgplot.gaintype_unintentional and h.randomtruefalse(settings.CHANCE_UNINTENTIONAL_WG_TAG):
        tags.append(random.choice(settings.UNINTENTIONAL_WG_TAGS))
    elif is_intentional and wgplot.gaintype_intentional and h.randomtruefalse(settings.CHANCE_INTENTIONAL_WG_TAG):
        tags.append(random.choice(settings.INTENTIONAL_WG_TAGS))
    elif wgplot.gaintype_noweightgain and h.randomtruefalse(settings.CHANCE_ALWAYS_CHUBBY_TAG):
        tags.append(random.choice(settings.ALWAYS_CHUBBY_TAGS))

    #mutual wg tags
    if is_mutual and h.randomtruefalse(settings.CHANCE_MUTUAL_WG_TAG):
        tags.append(random.choice(settings.MUTUAL_WG_TAGS))

    #relationship type tags
    if is_establishedrelationship and h.randomtruefalse(settings.CHANCE_RELATIONSHIP_TYPE_TAG):
        tags.append('Established Relationship') #always this tag
        if h.randomtruefalse(settings.CHANCE_RELATIONSHIP_TYPE_TAG):
            tags.append(random.choice(settings.ESTABLISHED_RELATIONSHIP_TAGS)) #chance of addt'l 1 tag
    elif not is_establishedrelationship and h.randomtruefalse(settings.CHANCE_RELATIONSHIP_TYPE_TAG): #new relationship has chance of 2 tags
        tags.append(random.choice(settings.NEW_RELATIONSHIP_TAGS))
        if h.randomtruefalse():
            tags.append(random.choice(settings.NEW_RELATIONSHIP_TAGS))


    # prompt.log("is_establishedrelationship", is_establishedrelationship, tags)

    if h.randomtruefalse(settings.CHANCE_WG_TAG):
        tags.append(random.choice(settings.WG_TAGS))

    # prompt.log('getautomatictags tags', len(tags), tags)

    # replace markup in tags
    pronounreplacementlist = textreplacement.getpronounreplacementlist(characters)
    finaltags = []
    for tag in tags:
        s = tag
        if '[' in s:
            for pronounreplacement in pronounreplacementlist:
                searchstring = textreplacement.encloseinwrapper(pronounreplacement[0], '[]')
                # prompt.log(s, searchstring, pronounreplacement[1])
                s = s.replace(searchstring, pronounreplacement[1])
                # prompt.log(s)

            prompt.log('s after pronoun replacement',s)

        if '{' in s:
            oldtext = s
            newtext = ''
            w = 0
            while oldtext != newtext:
                oldtext = newtext

                s = textreplacement.replacesinglechoice(s)
                s = textreplacement.replacemultiplechoice(s)

                newtext = s
                w += 1
                if w > 50:
                    prompt.log('!infinite loop getautomatictags()')
                    break

        # prompt.log('s after choices replacement',s)
        finaltags.append(s)

    # prompt.log('getautomatictags finaltags', len(finaltags), finaltags)

    random.shuffle(finaltags)

    return finaltags


def getpairingtag(characters):
    """ Returns tag (str) """

    characternames = [(character['fname'].strip() + ' ' + character ['lname'].strip()) for character in characters]
    characternames = sorted(characternames)
    tag = characternames[0] + '/' + characternames[1]
    return tag

def getchubbycharactertags(characters, is_mutual):
    """ Returns tags (list) """

    tags = []
    tags.append('Chubby'+' '+characters[0]['fname'])
    if is_mutual:
        tags.append('Chubby' + ' ' + characters[1]['fname'])
    return tags

def getfreeformtags(plot):
    """ Returns tags (list) """
    tags = []

    requiredtags = []
    optionaltags = []

    for tag in [t for t in plot.freeform_tags.split('\r\n') if t != '']:
        if '*' in tag:
            tag = tag.replace('*','')
            requiredtags.append(tag)
        else:
            optionaltags.append(tag)

    tags.extend(requiredtags)
    tags.extend(choose_n_tags(optionaltags, 1, 3))

    return tags



def gettagsfromplotattribute(plot, attribute, maxtags=1):
    """ Returns tags (list) """

    tags = []
    optionaltags = []

    tagslist = [t for t in getattr(plot, attribute).split('\r\n') if t != '']

    for tag in tagslist:
        if '*' in tag:
            tag = tag.replace('*','')
            tags.append(tag)
        else:
            optionaltags.append(tag)

    maxtags = maxtags - len(tags)
    if maxtags >= 1:
        tags.extend(choose_n_tags(optionaltags, 1, maxtags))

    return tags




def choose_n_tags(tags, lowerlimit, upperlimit, name=''):
    chosentags = []

    try:
        n = random.randint(lowerlimit, upperlimit)
        i = 0
        for _ in range(20):
            tag = random.choice(tags)
            if tag not in chosentags:
                try:
                    s = tag.text
                except:
                    s = tag
                if s != '':
                    chosentags.append(s)
                    i = i + 1
            if i >= n:
                break
    except IndexError:
        pass

    #prompt.log('choose_n_tags()',name,':',chosentags)
    return chosentags


def removeduplicatetags(tags):
    uniquetags = []

    for tag in tags:
        alreadyexists = False
        # prompt.log('uniquetags',uniquetags)
        for uniquetag in uniquetags:
            # prompt.log(tag.lower(), uniquetag.lower())
            if tag.lower() == uniquetag.lower():
                alreadyexists = True
        if not alreadyexists:
            uniquetags.append(tag)

    return uniquetags



#-----------------------------------------------------


def assigncharacterorder(characters):
    #sort
    if bothgainers(characters):
        random.shuffle(characters)
    else:
        #sort gaining character as [0], non-gaining as [1]
        characters = sorted(characters, key=lambda character: not character['gainer'])

    #assign numbers
    for i, character in enumerate(characters):
        character['characternumber'] = str(i+1) #i=0 but first character=1

    return characters


def getismutual(wgplot, characters):
    """ Returns True if both characters are chubby """

    if wgplot.is_mutual == 'YES':
        is_mutual = True
    elif wgplot.is_mutual == 'OPTIONAL' and bothgainers(characters):
        is_mutual = h.randomtruefalse(settings.CHANCE_IS_MUTUAL)
    else:
        is_mutual = False

    prompt.log('mutual', is_mutual)

    return is_mutual


def bothgainers(characters):
    if characters[0]['gainer'] and characters[1]['gainer']:
        return True
    else:
        return False

def getisestablishedrelationship(wgplot):
    prompt.log("type_of_relationship", wgplot.type_of_relationship)

    if wgplot.type_of_relationship == 'ESTABLISHED':
        is_establishedrelationship = True

    elif wgplot.type_of_relationship == 'EITHER' and h.randomtruefalse(settings.CHANCE_ESTABLISHED_RELATIONSHIP):
        is_establishedrelationship = True

    else:
        is_establishedrelationship = False
            # try:
            #     if wgcauseplot.type_of_relationship == 'ESTABLISHED' or wgcauseplot.type_of_relationship == 'EITHER':
            #         is_establishedrelationship = True
            # except:
            #     try:
            #         if wgrandomplot.type_of_relationship == 'ESTABLISHED' or wgrandomplot.type_of_relationship == 'EITHER':
            #             is_establishedrelationship = True
            #     except:
            #         pass

    return is_establishedrelationship

def getisintentional(wgplot):
    if not wgplot.gaintype_intentional:
        is_intentional = False
    #if there are no other options, then must be intentional
    elif not wgplot.gaintype_unintentional and not wgplot.gaintype_noweightgain:
        is_intentional = True
    #if there are other options, then roll the dice
    elif h.randomtruefalse(settings.CHANCE_UNINTENTIONAL_WG_TAG):
        is_intentional = True
    else:
        is_intentional = False

    return is_intentional

#-----------------------------------------------------

def removeduplicateitemsfromlist(seq, idfun=None):
   # order preserving
   if idfun is None:
       def idfun(x): return x
   seen = {}
   result = []
   for item in seq:
       marker = idfun(item)
       # in old Python versions:
       # if seen.has_key(marker)
       # but in new ones:
       if marker in seen: continue
       seen[marker] = 1
       result.append(item)
   return result


def weightedchoice(choices):
    values, weights = zip(*choices)
    total = 0
    cum_weights = []
    for w in weights:
        total += w
        cum_weights.append(total)
    x = random.random() * total
    i = bisect.bisect(cum_weights, x)
    return values[i]


















