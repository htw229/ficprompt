import random
from bisect import bisect

# from ficpromptapp.models import Frequency

# frequencyweight = { }
# frequencyobjectlist = Frequency.objects.values()
# for frequencydict in frequencyobjectlist:
#     frequencyweight[frequencydict['id']] = frequencydict['weight']

# def getobjectfrequencylist(objects):
#     obj_list = objects.values_list('id','frequency')

#     objectszip = list(zip(*obj_list))

#     obj_idlist = objectszip[0]

#     freq_idlist = objectszip[1]

#     obj_weightlist = map(lambda freqid: frequencyweight[freqid], freq_idlist)

#     return obj_idlist, obj_weightlist

def weightedchoice(objects):
    try:
        objects = objects.objects.all()
        #log.p('objects is all objects')
    except:
        #log.p('objects is a query')
        pass

    ids, weights = getobjectfrequencylist(objects)

    total = 0
    cum_weights = [ ]
    for w in weights:
        total += w
        cum_weights.append(total)
    x = random.random() * float(total)
    i = bisect(cum_weights, x)

    obj_id = ids[i]

    return objects.get(id=obj_id)

def getmaxobjects(incrementchance):
    max_obj = 0
    for chance in incrementchance:
        if random.random() < chance:
            max_obj += 1
    return max_obj


def removeduplicates(seq):
    result = []
    for item in seq:
        if not item in result:
            result.append(item)
    return result



# def randomitem(objects):
#     # try:
#     #     objects = objects.objects.all()
#     # except:
#     #     #objects is already a query
#     #     pass

#     # n = objects.count()
#     # i = random.randint(0,n-1)

#     return random.choice(list(objects))

# def randomorder(seq):
#     random.shuffle(seq)
#     return seq

def randomtruefalse(percent=None):
    random.seed()

    if not percent:
        return random.choice([True,False])

    else:
        if random.random() <= percent:
            return True
        else:
            return False





print('hello')





