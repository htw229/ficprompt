import datetime
from zipfile import ZipFile

from django.core import serializers

# from ficpromptapp.models import livemodels, betamodels, allmodels
from ficpromptapp.models import backupmodels
# import backup
import logfile as log
log.newlogfile()

backupfolder = 'dbbackup/'

def backupdatabase():
    zipfilepath = backupfolder + 'ficpromptbackup_'
    zipfilepath += datetime.datetime.now().strftime('%Y_%m_%d_%H-%M')
    zipfilepath += '.zip'

    with ZipFile(zipfilepath, 'w') as backupzip:
        for model in backupmodels:
            log.p('backing up',model.__name__)
            modelfilename = model.__name__ + '.xml'
            modeldata = serializers.serialize('xml',model.objects.all())
            backupzip.writestr(modelfilename,modeldata)

def importxmlfromzip():
    zipfilepath = backupfolder + 'import.zip'

    with ZipFile(zipfilepath, 'r') as importzip:
        filelist = importzip.namelist()
        # log.p(filelist)
        for filename in filelist:
            data = importzip.open(filename)
            for obj in serializers.deserialize('xml',data):
                obj.save()
                log.p(filename,obj)

# def migratelivetobeta():
#     log.p('migratelivetobeta')
#     if input('this will delete all objects from BETA models y/n') is not 'y':
#         log.p('exiting')
#         return

#     migratemodels(frommodels=livemodels,tomodels=betamodels)

def migratebetatolive(betamodel, livemodel):
    log.p('migratebetatolive')

    # backup.makebackup()
    if input('this will delete all objects from LIVE models y/n') is not 'y':
        log.p('exiting')
        return

    backupdatabase()
    migratemodel(frommodel=betamodel,tomodel=livemodel)


def migratemodel(frommodel, tomodel):
    frommodelfieldnames = [f.name for f in frommodel._meta.get_fields()]
    tomodelfieldnames = [f.name for f in tomodel._meta.get_fields()]

    #verify models contain same fields
    if len(set(frommodelfieldnames) & set(tomodelfieldnames)) == len(frommodelfieldnames):
        log.p(frommodel,'from and to contain same fields, continue')
    else:
        log.p(frommodel,'from and to DO NOT contain same fields')
        log.p('frommodel',frommodelfieldnames)
        log.p('tomodel',tomodelfieldnames)
        return

    frommodelobjects = frommodel.objects.all()
    tomodelobjects = tomodel.objects.all()

    #if there are more objects in the 'to model' that will be deleted
    #than in the 'from model', confirm deletion
    if len(tomodelobjects) > len(frommodelobjects):
        if input(str(tomodel)+' has more objects than '+str(frommodel)+' continue? y/n') is not 'y':
            log.p('exiting')
            return

    i = -1
    for i, obj in enumerate(tomodelobjects):
        obj.delete()
    log.p(i+1, 'objects deleted')

    for i, obj in enumerate(frommodelobjects):
        newobj = tomodel()
        for fieldname in frommodelfieldnames:
            attr = getattr(obj,fieldname)

            if attr == 'id' or attr == 'pk': #skip 'id' field
                continue
            setattr(newobj,fieldname,attr)
        newobj.save()
        # log.p(str(newobj),'saved')
    log.p(i+1, 'objects migrated')


def migratemodels(frommodels,tomodels):
    # backup.makebackup()

    for i, frommodel in enumerate(frommodels):
        log.newline()
        tomodel = tomodels[i]

        frommodelfieldnames = frommodel._meta.get_all_field_names()
        tomodelfieldnames = tomodel._meta.get_all_field_names()

        #verify models contain same fields
        if len(set(frommodelfieldnames) & set(tomodelfieldnames)) == len(frommodelfieldnames):
            log.p(frommodel,'from and to contain same fields, continue')
        else:
            log.p(frommodel,'from and to DO NOT contain same fields')
            log.p('frommodel',frommodelfieldnames)
            log.p('tomodel',tomodelfieldnames)
            return

        frommodelobjects = frommodel.objects.all()
        tomodelobjects = tomodel.objects.all()

        #if there are more objects in the 'to model' that will be deleted
        #than in the 'from model', confirm deletion
        if len(tomodelobjects) > len(frommodelobjects):
            if input(str(tomodel)+' has more objects than '+str(frommodel)+' continue? y/n') is not 'y':
                log.p('exiting')
                return

        for o, obj in enumerate(tomodelobjects):
            obj.delete()
        log.p('objects deleted')

        for obj in frommodelobjects:
            newobj = tomodel()
            for fieldname in frommodelfieldnames:
                attr = getattr(obj,fieldname)

                if attr == 'id': #skip 'id' field
                    continue
                setattr(newobj,fieldname,attr)
            newobj.save()
            log.p(newobj,'saved')



