import random
from bisect import bisect

def removeduplicates(seq):
    result = []
    for item in seq:
        if not item in result:
            result.append(item)
    return result

def randomtruefalse(percent="None"):
    random.seed()

    if percent == "None":
        return random.choice([True,False])

    else:
        randomvalue = random.random()
        # prompt.log('randomvalue', randomvalue)
        if randomvalue <= percent:
            return True
        else:
            return False






