from django.shortcuts import render, redirect
import forms
import appsettings
# import random

#ficprompts
import ficprompts
import ficpromptsbeta

#chubbyprompts
import chubbyprompts
import chubbypromptsbeta
# htmltemplate = 'chubbyprompts.html'
# promptform = forms.ChubbyPromptsForm



def home(request):
    return render(request, 'home.html', {'right_now':'right_now'})

def robotstxt(request):
    return render(request, 'robots.txt')

def maintenance(request):
    return render(request, 'maintenance.html')

def chubbypromptsview(request, url = '/chubbyprompts/', n = 1, debug = False):
    """ Beta version 0.1
        n = number of prompts to display
        url is used in the html form submit button """

    renderdata = processchubbyprompts(request, url, n, debug)
    return renderdata

def chubbypromptsselectplotview(request, url = '/chubbyprompts/selectplot/', n = 1, debug = True):
    """ same as above but allows selecting plot """

    debug = True
    renderdata = processchubbyprompts(request, url, n, debug)
    return renderdata

def ficpromptsview(request, url = '/chubbyprompts/', n = 1, debug = False):
    """ Alpha version 0.01
        n = number of prompts to display
        url is used in the html form submit button """

    renderdata = processficprompts(request, url, n, debug)
    return renderdata

def chubbyficpromptsview(request, url = '/chubbyprompts/', n = 1, debug = False):
    """ Alpha version 0.01
        n = number of prompts to display
        url is used in the html form submit button """

    renderdata = processficprompts(request, url, n, debug, chubby = True)
    return renderdata


#TEXTS#
def textsforao3view(request, url = '/textsforao3/', debug = False):
    """ """

    htmltemplate = 'textsforao3.html'


    requestdata = {
        'url': url,
    }

    return render(request, htmltemplate, requestdata)



#REDIRECTS#
def ckprompts(request):
    return redirect('/chubbyprompts/')




#---------------------------------------------------------------



def processficprompts(request, url, iterations, debug, chubby = False):
    htmltemplate = 'ficprompts.html'
    promptform = forms.FicPromptsForm

    #get request data
    query = request.GET

    characters = []

    for i in range(iterations):
        characters.append([
            {
                'fname':query.get('A_fname'),
                'lname':query.get('A_lname'),
                'pronoun':query.get('A_pronoun'),
            },
            {
                'fname':query.get('B_fname'),
                'lname':query.get('B_lname'),
                'pronoun':query.get('B_pronoun'),
            },
        ])

    if debug:
        characters = []
        # random.shuffle(appsettings.DEBUG_CHARACTERS)
        for i in range(iterations):
            characters.append(appsettings.DEBUG_CHARACTERS[i])

    # pkplot = query.get('pkplot')

    prompts = []
    prompt = {}
    logs = []

    #get and validate form
    if query:
        form = promptform(data = query, initial = query)
    else:
        form = promptform()

    if form.is_valid():
        for i in range(iterations):
            if not debug:
                prompt = ficprompts.getprompt(
                    characters[i],
                    query.get('pkplot'),
                    query.get('pkplotline'),
                    query.get('pksetting'),
                    chubby = chubby,
                )
            else:
                prompt = ficpromptsbeta.getprompt(
                    characters[i],
                    query.get('pkplot'),
                    query.get('pkplotline'),
                    query.get('pksetting'),
                    chubby = chubby,
                )

            debugdata = [
                str(i),
                # 'characters=' + characters[i]
                # 'plot=' + str(prompt['plot']),
            ]

            prompt['debugdata'] = '<br/>'.join(debugdata)

            prompts.append(prompt)

            prompt['logs'].insert(0,i+1)
            logs.append(prompt['logs'])
    else:
        prompt = {}

    logs.insert(0, [query])
    logs.insert(0, [chubby])

    requestdata = {
        'form':form,
        'prompts':prompts,
        'logs': logs,
        'debug': debug,
        'chubby': chubby,
        'url': url,
    }

    return render(request, htmltemplate, requestdata)


def processchubbyprompts(request, url, iterations, debug):
    htmltemplate = 'chubbyprompts.html'
    promptform = forms.ChubbyPromptsForm

    #get request data
    query = request.GET

    characters = [
        {
            'fname':query.get('A_fname'),
            'lname':query.get('A_lname'),
            'startweight':query.get('A_startweight'),
            'pronoun':query.get('A_pronoun'),
            'gainer':query.get('A_gainer'),
        },
        {
            'fname':query.get('B_fname'),
            'lname':query.get('B_lname'),
            'startweight':query.get('B_startweight'),
            'pronoun':query.get('B_pronoun'),
            'gainer':query.get('B_gainer'),
        },
    ]

    pkwgplot = query.get('pkwgplot')
    pkwgcause = query.get('pkwgcause')
    pkwgrandom = query.get('pkwgrandom')

    prompts = []
    prompt = {}
    logs = []

    #get and validate form
    if query:
        form = promptform(data = query, initial = query)
    else:
        form = promptform()

    if form.is_valid():
        for i in range(iterations):
            if not debug:
                prompt = chubbyprompts.getprompt(characters,pkwgplot,pkwgcause,pkwgrandom)
            else:
                prompt = chubbypromptsbeta.getprompt(characters,pkwgplot,pkwgcause,pkwgrandom)

            debugdata = [
                str(i+1),
                'wgplot=' + str(prompt['wgplot']),
                'wgcause=' + str(prompt['wgcause']),
                'wgrandom=' + str(prompt['wgrandom'])
            ]

            prompt['debugdata'] = '<br/>'.join(debugdata)

            prompts.append(prompt)

            prompt['logs'].insert(0,i+1)
            logs.append(prompt['logs'])
    else:
        prompt = {}

    logs.insert(0, [query])

    requestdata = {
        'form':form,
        'prompts':prompts,
        'logs': logs,
        'debug': debug,
        'url': url,
    }

    return render(request, htmltemplate, requestdata)












