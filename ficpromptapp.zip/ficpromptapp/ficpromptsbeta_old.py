import random
import re
import bisect

import prompt
import prompthelpers as h
from ficpromptapp.models import Plot

#BETA
import ficpromptstextreplacementbeta as textreplacement

def getprompt(characters, pkmainplot):
    prompt.resetprompt()

    characters = assigncharacterorder(characters)

    try:
        plot = Plot.objects.get(pk=pkmainplot)
    except:
        plot = random.choice(Plot.objects.all())

    #get prompt text
    plottext = chooseline(plot.text, divider = '#')

    #get tags
    tags = gettags(plot)

    plottext = replaceoptionsandchoices(plottext, plot, characters)
    tags = [replaceoptionsandchoices(t, plot, characters) for t in tags]

    # format text
    plottext = textreplacement.linebreak_to_paragraph(plottext)

    prompt.prompt['text'] = plottext
    prompt.prompt['tags'] = tags

    return prompt.prompt


def replaceoptionsandchoices(text, plot, characters):
    pronounreplacementlist = textreplacement.getpronounreplacementlist(characters)

    text = loopreplacetext(
        text,
        replaceoptions,
        textreplacement.replacetextfromlist,
        textreplacement.replacerandomint,
        textreplacement.replacegenderchoice,
        textreplacement.replacesinglechoice,
        textreplacement.replacemultiplechoice,
        plot = plot,
        characters = characters,
        wrapper = '[]',
        searchreplacelist = pronounreplacementlist,
    )

    return text

def replaceoptions(text, plot, characters, **kwargs):
    staticoptionsreplacementlist = getstaticoptionsreplacementlist(plot, characters)

    text = loopreplacetext(
        text,
        textreplacement.replacetextfromlist,
        replacevariableoptions,
        searchreplacelist = staticoptionsreplacementlist,
        plot = plot,
    )

    return text


# def replacetextfromchoices(text, plot, characters, **kwargs):
#     #replace randomint
#     text = loopreplacetext(
#         text,
#         textreplacement.replacerandomint,
#     )

#     ## TODO synonyms (needs a loop)

#     # replace choices
#     text = loopreplacetext(
#         text,
#         textreplacement.replacegenderchoice,
#         textreplacement.replacesinglechoice,
#         textreplacement.replacemultiplechoice,
#         characters = characters
#     )

#     prompt.log('replacetextfromchoices: new text=', text)

#     return text

def gettags(plot):
    tags = getlistfromlines(plot.tags)
    tags = choose_n_tags(tags, lowerlimit = 1, upperlimit = 3)
    return tags


def choose_n_tags(tags, lowerlimit = 1, upperlimit = 2):
    chosentags = []
    choosetag = textreplacement.randomoptiongenerator(tags, limitreuse = True)

    n = random.randint(lowerlimit, upperlimit)
    for _ in range(n):
        try:
            chosentags.append(next(choosetag))
        except StopIteration:
            break

    return chosentags

def getstaticoptionsreplacementlist(plot, characters):
    optionfields = plot.getoptionfields()
    optionsreplacementlist = []

    for (option_field, option_markup) in optionfields['static']:
        optiontext = getattr(plot, option_field)
        optiontext = chooseline(optiontext)

        # optiontext = replaceconstants(optiontext, characters)
        # optiontext = replacechoices(optiontext, characters)

        optionsreplacementlist.append([option_markup, optiontext])

    return optionsreplacementlist

def replacevariableoptions(text, plot, **kwargs):
    optionfields = plot.getoptionfields()

    for (option_field, option_markup) in optionfields['variable']:
        optiontext = getattr(plot, option_field)
        optionlist = getlistfromlines(optiontext, linebreak = True, divider = '')
        randomoption = textreplacement.randomoptiongenerator(optionlist)

        while option_markup in text:
            text = text.replace(option_markup, next(randomoption), 1)

    return text

# def textreplacement.randomoptiongenerator(optionslist, limitreuse = False):
#     """ Given a list of text, will randomly select a next option.
#         Uses markup at beginning of line:
#             * = required (will be selected first)
#             + = common (will be selected at frequency of commonoptionmultiplier)
#             - = uncommon
#             & = if limitreuse=True, allows reuse of this line
#         Yields string """

#     pstart = r'^[\*&\+\-]*'
#     pend = r'[\*&\+\-]*\s*(.+)'

#     commonoptionmultiplier = 20
#     otheroptionmultiplier = 10
#     uncommonoptionmultiplier = 8

#     weightedoptions = []

#     for textitem in optionslist:
#         matchrequired = re.search(pstart + r'\*' + pend, textitem)
#         matchcommon = re.search(pstart + r'\+' + pend, textitem)
#         matchuncommon = re.search(pstart + r'\-' + pend, textitem)

#         matchcanreuse = re.search(pstart + r'\&' + pend, textitem)
#         if matchcanreuse:
#             canreuse = True
#         else:
#             canreuse = False

#         if matchrequired:
#             yield matchrequired.group(1)
#             if not canreuse:
#                 continue

#         if matchcommon:
#             weightedoptions.append({
#                 'text': matchcommon.group(1),
#                 'canreuse': canreuse,
#                 'weight': commonoptionmultiplier,
#             })
#         elif matchuncommon:
#             weightedoptions.append({
#                 'text': matchuncommon.group(1),
#                 'canreuse': canreuse,
#                 'weight': uncommonoptionmultiplier,
#             })
#         else:
#             weightedoptions.append({
#                 'text': textitem,
#                 'canreuse': canreuse,
#                 'weight': otheroptionmultiplier,
#             })

#     alloptions = [x for x in weightedoptions]

#     while True:
#         while len(weightedoptions) >= 1:
#             weightedoptions.sort(key = lambda item: random.random() * item['weight'], reverse = True)
#             if weightedoptions[0]['canreuse']:
#                 yield weightedoptions[0]['text']
#             else:
#                 yield weightedoptions.pop(0)['text']

#         if not limitreuse:
#             #repopulate weightedoptions and loop over again
#             weightedoptions = [x for x in alloptions]
#         if limitreuse:
#             return None



# def weightedchoice(choices):
#     """ Given list of [(choice, weight),...]
#         Chooses a random item, likelihood based on weight
#         Returns item """

#     values, weights = zip(*choices)
#     total = 0
#     cum_weights = []
#     for w in weights:
#         total += w
#         cum_weights.append(total)
#     x = random.random() * total
#     i = bisect.bisect(cum_weights, x)
#     return values[i]


# def weightedchoiceposition(choices):
#     """ Just like weighted choice above,
#         But returns position of item instead of item itself """

#     values, weights = zip(*choices)
#     total = 0
#     cum_weights = []
#     for w in weights:
#         total += w
#         cum_weights.append(total)
#     x = random.random() * total
#     i = bisect.bisect(cum_weights, x)
#     return i



# def createintegerlist(floatlist):
#     """ Given list of numbers that may contain floats,
#         finds a multiplier that will make all integers
#         Used for sake of comparison
#         (ex. common = 1, uncommon = 0.25 -> common = 4, uncommon = 1)
#         Returns list of integers """

#     multiplier = 1

#     for n in floatlist:
#         w = 0
#         prompt.log('n', n)
#         while int(n * multiplier) != n * multiplier:
#             w += 1
#             if w > 100:
#                 prompt.log('infinite loop: createintegerlist')
#                 break

#     integerlist = [int(n * multiplier) for n in floatlist]
#     return integerlist

# def createintegerlist(*floatlist):
#     """ Given list of numbers that may contain floats,
#         finds a multiplier that will make all integers
#         Used for sake of comparison
#         (ex. common = 1, uncommon = 0.25 -> common = 4, uncommon = 1)
#         Returns list of integers """

#     multiplier = 1

#     for n in floatlist:
#         w = 0
#         prompt.log('n', n)
#         while int(n * multiplier) != n * multiplier:
#             w += 1
#             if w > 100:
#                 prompt.log('infinite loop: createintegerlist')
#                 break

#     integerlist = [int(n * multiplier) for n in floatlist]
#     return integerlist

# def replaceconstants(text, characters):
#     # replace pronouns
#     pronounreplacementlist = textreplacement.getpronounreplacementlist(characters)
#     text = textreplacement.replacetextfromlist(text, pronounreplacementlist, wrapper = '[]')

#     #replace randomint
#     text = loopreplacetext(
#         text,
#         textreplacement.replacerandomint,
#     )

#     return text

# def replacechoices(text, characters):
#     text = loopreplacetext(
#         text,
#         textreplacement.replacegenderchoice,
#         textreplacement.replacesinglechoice,
#         textreplacement.replacemultiplechoice,
#         characters = characters
#     )

#     return text


def assigncharacterorder(characters):
    characters = h.randomorder(characters)
    #assign numbers
    for i, character in enumerate(characters):
        character['characternumber'] = str(i+1) #i=0 but first character=1

    return characters


def loopreplacetext(text, *funs, **kwargs):
    oldtext = ''
    w = 0

    while text != oldtext:
        oldtext = text

        for fun in funs:
            text = fun(text, **kwargs)

        w += 1
        if w > 25:
            prompt.log('infinite loop: loopreplacetext!')
            break

    return text


def chooseline(text, linebreak = True, divider = ''):
    if linebreak and divider == '':
        divider = '\r\n'
    lines = [t for t in text.split(divider) if t.strip() != '']
    # prompt.log('lines', lines)

    if len(lines) > 0:
        line = random.choice(lines).strip(divider).strip()
        if line == '<none>':
            line = ''
    else:
        line = ''

    # prompt.log('line', line)

    return line

def getlistfromlines(text, linebreak = True, divider = ''):
    if linebreak and divider == '':
        divider = '\r\n'
    lines = [t for t in text.split(divider) if t.strip() != '']

    return lines
