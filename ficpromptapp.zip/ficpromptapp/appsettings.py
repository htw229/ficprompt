from collections import OrderedDict

APP_ROOT = '/home/htw/ficprompt/'

FREQUENCIES = OrderedDict()
FREQUENCIES['VERY COMMON'] = 1.5
FREQUENCIES['COMMON'] = 1
FREQUENCIES['UNCOMMON'] = 0.5
FREQUENCIES['RARE'] = 0.25

ADJUST_OBJ_FREQUENCY = OrderedDict()
ADJUST_OBJ_FREQUENCY['PLOTLINE'] = 2.0
ADJUST_OBJ_FREQUENCY['SETTING'] = 1.5
ADJUST_OBJ_FREQUENCY['UNIVERSE'] = 1.25


PLOT_FREQUENCY = {
    'VERY_COMMON': 1.5,
    'COMMON': 1.0,
    'RARE': 0.5
}

MAX_TAG_WORDS_FOR_TITLECASE = 4

TAG_ORDER = [
    'PAIRING',
    'ALTERNATEUNIVERSE',
    'ROLE',
    'CHUBBYCHARACTER',
    'CHARACTERATTRIBUTE',
    'RELATIONSHIPSTATUS',
    'PROMPTFREEFORM',
	'TAGFREEFORM',
 	'FLUFFANGST',
]


ROLE_SELECTION_CHOICES = (
    ('PLOT_', 'Plot only'),
    ('PLOTLINE_', 'Plotline only'),
    ('SETTING_', 'Setting only'),
    ('PLOT_PLOTLINE_', 'Plot or Plotline'),
    ('PLOTLINE_SETTING_', 'Plotline or Setting'),
    ('PLOT_PLOTLINE_SETTING_', 'Any'),
    ('NONE', 'None'),
)

# MAX_PLOTSETTINGUNIVERSE_TAGS = 3


# MIN_FREEFORM_TAGS = 2

MAX_SETTING_TAGS = 1
MAX_PLOTLINE_TAGS = 2
MAX_PLOT_TAGS = 3
MAX_FREEFORM_TAGS = 6

# MAX_CAPITALIZED_WORDS_IN_TAG = 5

CHANCE_OF_ANGST = 0.30
CHANCE_OF_FLUFF = 0.80

# CHANCE_OF_ROLE_IN_TAGS = 1
CHANCE_OF_ATTRIBUTE = 0.4
CHANCE_OF_SECOND_ATTRIBUTE = 0.2
# CHANCE_OF_GEN_PLOT_DEVICE = 1
# CHANCE_OF_ROMANCE_PLOT_DEVICE = 1

CHANCE_OF_NO_ROLE = 0.5 # if 'NONE' is option in roleselection
CHANCE_OF_ROLE_TAG = 1


# choose very basic ones here
# under fluff/angst and other tagtypes, can do others
# such as hurt/comfort, dark etc in Fluff/Angst tags
CHANCE_FLUFF_ANGST_TAG = 0.5

FLUFF_ONLY_TAGS = "\r\n".join(
    ['+fluff',]
)

ANGST_ONLY_TAGS = "\r\n".join(
    ['+angst',]
)

FLUFF_AND_ANGST_TAGS = "\r\n".join(
    ['+fluff and angst',]
)

# CHANCE_BASIC_TAGS_ONLY = 0.66


# FREEFORM_TAG_PRIORITY = {
#     'STANDARD': {
#         'plot': 2,
#         'role': 2,
#         'relationshipstatus': 1,
#         'tagobject': 0,
#         'fluffangst': 1,
#     },
#     'CANONCOMPLIANT': {
#         'plot': -1,
#         'role': -1,
#         'relationshipstatus': 1,
#         'tagobject': 1,
#         'fluffangst': 1,
#     },
# }

##### CHUBBY ######
CHANCE_SECOND_CHUBBY_CHARACTER = 0.15



## WG ##

#chance established relationship
CHANCE_ESTABLISHED_RELATIONSHIP = 0

#percent chance of having additional plot (0-1.0)
CHANCE_WG_CAUSE_PLOT = 0.75
CHANCE_RANDOM_WG_PLOT = 0.75
CHANCE_WG_CAUSE_VS_RANDOM_WG_PLOT = 0.75

#percent chance type of weight gain
CHANCE_IS_MUTUAL = 0.0
CHANCE_IS_INTENTIONAL = 0.1

#chance of automatic tags
CHANCE_UNINTENTIONAL_WG_TAG = 0.4

UNINTENTIONAL_WG_TAGS = [
    'Accidental Weight Gain',
    'Unintentional Weight Gain',
    'Weight Gain',
]

CHANCE_INTENTIONAL_WG_TAG = 0.4
INTENTIONAL_WG_TAGS = [
    'Deliberate Weight Gain',
    'Intentional Weight Gain',
    'Stuffing',
    'Weight Gain',
]

CHANCE_ALWAYS_CHUBBY_TAG = 0.5
ALWAYS_CHUBBY_TAGS = [
    'Always Chubby [1]',
    "[1] has always been chubby",
]

CHANCE_MUTUAL_WG_TAG = 0.5
MUTUAL_WG_TAGS = [
    'Mutual Weight Gain',
]

CHANCE_RELATIONSHIP_TYPE_TAG = 0.5
ESTABLISHED_RELATIONSHIP_TAGS = [
    'Established Relationship',
    'Moving in together',
    '{Proposal ||}',
    '{Jealousy | Jealous [1] | Jealous [2]}',
    'Meeting the family',
    'Misunderstandings',
    'Miscommunication',
    'Long Distance Relationship',
]

NEW_RELATIONSHIP_TAGS = [
    'First Kiss',
    'First Time',
    'First Date',
    'Getting Together',
    '{Pining [1] & Pining [2] | Pining [1] | Pining [2] | Mutual Pining}',
    '{Oblivious [1] | Oblivious [2]}',
    '{Blind Date | Online Dating | Fuck Buddies | Hooking Up | Friends to Lovers}',
    '{Sexting}',
    'Confessions',
]


CHANCE_WG_TAG = 0.33
WG_TAGS = [
    'Button Popping',
    'Outgrowing Clothes',
    'Tight Clothes',
    '{Numbers Kink | Measurement Kink}',
    'Out of Shape',
    'Insecurity',
    'Chubby Kink',
    'Teasing',
    'Body Worship',
    'Belly Rubs',
    'Belly Kink',
    'Weight Gain Kink',
    'Weight Issues',
    'Body Image Issues',
    '{Closeted} Chubby Chaser [2]',
    'Secret Chubby Kink',
]



#determines multiplier for common vs uncommon synonyms
COMMON_SYNONYM_MULTIPLIER = 3


#debug characters
DEBUG_CHARACTERS = [
    [
        {
            'fname':'Castiel',
            'lname':'',
            'pronoun':'HE',
            'chubby':'True',
        },
        {
            'fname':'Dean',
            'lname':'Winchester',
            'pronoun':'HE',
            'chubby':'True',
        },
    ],
    [
        {
            'fname':'Stiles',
            'lname':'Stilinski',
            'pronoun':'HE',
            'chubby':'True',
        },
        {
            'fname':'Derek',
            'lname':'Hale',
            'pronoun':'HE',
            'chubby':'False',
        },
    ],
    [
        {
            'fname':'Levi',
            'lname':'',
            'pronoun':'HE',
            'chubby':'False',
        },
        {
            'fname':'Erin',
            'lname':'Yeager',
            'pronoun':'HE',
            'chubby':'True',
        },
    ],
    [
        {
            'fname':'Killian',
            'lname':'Jones',
            'pronoun':'HE',
            'chubby':'False',
        },
        {
            'fname':'Emma',
            'lname':'Swan',
            'pronoun':'SHE',
            'chubby':'True',
        },
    ],
    [
        {
            'fname':'Clint',
            'lname':'Barton',
            'pronoun':'HE',
            'chubby':'True',
        },
        {
            'fname':'Natasha',
            'lname':'Romanov',
            'pronoun':'SHE',
            'chubby':'False',
        },
    ],
    [
        {
            'fname':'Clarke',
            'lname':'Griffin',
            'pronoun':'SHE',
            'chubby':'True',
        },
        {
            'fname':'Lexa',
            'lname':'',
            'pronoun':'SHE',
            'chubby':'False',
        },
    ],
    [
        {
            'fname':'Laura',
            'lname':'Hollis',
            'pronoun':'SHE',
            'chubby':'True',
        },
        {
            'fname':'Carmilla',
            'lname':'Karnstein',
            'pronoun':'SHE',
            'chubby':'True',
        },
    ],
    [
        {
            'fname':'Peggy',
            'lname':'Carter',
            'pronoun':'SHE',
            'chubby':'False',
        },
        {
            'fname':'Angie',
            'lname':'Martinelli',
            'pronoun':'SHE',
            'chubby':'True',
        },
    ],
    [
        {
            'fname':'Leo',
            'lname':'Fitz',
            'pronoun':'HE',
            'chubby':'True',
        },
        {
            'fname':'Jemma',
            'lname':'Simmons',
            'pronoun':'SHE',
            'chubby':'False',
        },
    ],
    [
        {
            'fname':'Harry',
            'lname':'Styles',
            'pronoun':'HE',
            'chubby':'False',
        },
        {
            'fname':'Louis',
            'lname':'Tomlinson',
            'pronoun':'HE',
            'chubby':'True',
        },
    ],
    [
        {
            'fname':'Bucky',
            'lname':'Barnes',
            'pronoun':'HE',
            'chubby':'True',
        },
        {
            'fname':'Steve',
            'lname':'Rogers',
            'pronoun':'HE',
            'chubby':'True',
        },
    ],
    [
        {
            'fname':'Chloe',
            'lname':'Beale',
            'pronoun':'SHE',
            'chubby':'False',
        },
        {
            'fname':'Beca',
            'lname':'Mitchell',
            'pronoun':'SHE',
            'chubby':'True',
        },
    ],
    [
        {
            'fname':'Sherlock',
            'lname':'Holmes',
            'pronoun':'HE',
            'chubby':'False',
        },
        {
            'fname':'John',
            'lname':'Watson',
            'pronoun':'HE',
            'chubby':'True',
        },
    ],
]

# if not sufficient DEBUG_CHARACTERS, then repeat
for i in range(20):
    DEBUG_CHARACTERS.extend(DEBUG_CHARACTERS)

