import os, sys

sys.path.insert(0,os.path.join(os.path.dirname(__file__), "common"))
sys.path.insert(0,os.path.join(os.path.dirname(__file__), "prompt"))
sys.path.insert(0,os.path.dirname(__file__))
sys.path.insert(0,'/home/htw/common/')