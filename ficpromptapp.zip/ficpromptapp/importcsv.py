import csv
from django.db.utils import IntegrityError

from ficpromptapp.models import Universe, Setting, Plotline, Plot, TagType, Tag, RelationshipStatus, Synonym, RoleSelection

importdir = '/home/htw/ficprompt/imports/'

angstfluffchoices = {
    '': 'ANY',
    'x': 'MUST_HAVE',
    '+': 'MUST_HAVE',
    '-': 'CANNOT_HAVE',
}

# uncommon is default
frequencychoices = {
    '++': 'VERY COMMON',
    '+': 'COMMON',
    '': 'UNCOMMON',
    '-': 'UNCOMMON',
    '--': 'RARE',
}

universechoices = {
    'highschool modern': ['highschool modern'],
    'highschool': ['highschool modern'],
    'historical': ['historical'],
    'modern': ['modern'],
    'other': ['other'],
    'anymodern': [
        'highschool modern',
        'modern',
    ],
    'hs': ['highschool modern'],
    'h': ['historical'],
    'm': ['modern'],
    'o': ['other'],
    'am': [
        'highschool modern',
        'modern',
    ],
    'not historical': [
        'highschool modern',
        'modern',
        'other',
    ],
    'nh': [
        'highschool modern',
        'modern',
        'other',
    ],
}

relationshipchoices = {
    'established': ['established relationship'],
    'e': ['established relationship'],
    'not established': [
        'acquaintances',
        'enemies',
        'exes',
        'friends',
        'fuck buddies',
        'strangers',
    ],
    'ne': [
        'acquaintances',
        'enemies',
        'exes',
        'friends',
        'fuck buddies',
        'strangers',
    ],
    'currentprior': [
        'exes',
        'established relationship',
    ],
    'cp': [
        'exes',
        'established relationship',
    ],
    'strangers': [
        'strangers',
    ],
    's': [
        'strangers',
    ],
    'not strangers': [
        'acquaintances',
        'enemies',
        'exes',
        'friends',
        'fuck buddies',
        'established relationship',
    ],
    'ns': [
        'acquaintances',
        'enemies',
        'exes',
        'friends',
        'fuck buddies',
        'established relationship',
    ],
    'not strangers not established' : [
        'acquaintances',
        'enemies',
        'exes',
        'friends',
        'fuck buddies',
    ],
    'nsne' : [
        'acquaintances',
        'enemies',
        'exes',
        'friends',
        'fuck buddies',
    ],
    'not established': [
        'acquaintances',
        'enemies',
        'exes',
        'friends',
        'fuck buddies',
        'strangers',
        'established relationship',
    ],
    'acquaintances':['acquaintances'],
    'enemies':['enemies'],
    'exes':['exes'],
    'friends':['friends'],
    'fuck buddies':['fuck buddies'],
    'strangers':['strangers'],
    'established relationship':['established relationship'],
}


def importtags():
    filename = input('file name: ')
    filename = filename.replace('.csv','')
    filepath = importdir + filename + '.csv'

    try:
        csvfile = open(filepath)
    except FileNotFoundError:
        print('File not found: ', filepath)
        return

    tagdict = csv.DictReader(csvfile)

    for tagdata in tagdict:
        newtag = Tag()

        newtag.name = tagdata['Tag'].lower()

        # name of tag is always higher priority in tag texts
        tagtexts = '+' + tagdata['Tag'].lower()

        additionaltagtexts = tagdata['Extra Tags'].lower()
        if additionaltagtexts:
            texts = additionaltagtexts.split('|')
            texts = [t.strip() for t in texts]
            tagtexts += '\r\n' + '\r\n'.join(texts)

        newtag.tags = tagtexts

        newtag.angst = angstfluffchoices[tagdata['Angst']]
        newtag.fluff = angstfluffchoices[tagdata['Fluff']]

        if tagdata['Chubby Prompt'] == 'x':
            newtag.chubbyprompt = True

        newtag.frequency = frequencychoices[tagdata['Frequency']]

        try:
            tagtype = TagType.objects.get(name = tagdata['Tag Type'])
        except:
            print('tagtype ' + tagdata['Tag Type'] + ' does not exist')
            continue

        newtag.tagtype = tagtype

        try:
            newtag.save()

            print('add: ' + newtag.name)
        except:
            oldtag = Tag.objects.get(name = newtag.name)
            msg = 'Duplicate tag name: ' + newtag.name
            msg += ' | Old tags: ' + oldtag.tags
            msg += ' | New tags: ' + newtag.tags
            print(msg)
            if input('Combine tagtexts? y/n  ') == 'y':
                oldtag.tags += '\r\n' + newtag.tags
                oldtag.save()
                continue
            elif input('Add new tag with new name? y/n ') == 'y':
                tagname = input('new tag name: ')
                newtag.name = tagname
                newtag.save()
            elif input('Replace old tag with new tag? y/n ') == 'y':
                oldtag.delete()
                newtag.save()
            else:
                print('skipping tag')
                continue

        #manytomany must be added after save

        #required relationships
        requiredrelationshipkey = tagdata['Required Relationship'].lower()
        try:
            possiblerelationshipnames = relationshipchoices[requiredrelationshipkey]
        except KeyError:
            possiblerelationshipnames = None
        if possiblerelationshipnames:
            #name will be acquaintances, enemies, etc
            for name in possiblerelationshipnames:
                relationshipstatus = RelationshipStatus.objects.get(name = name)
                newtag.relationshipstatuses.add(relationshipstatus)

        #required universes
        universekey = tagdata['Required Universe'].lower()
        try:
            possibleuniversenames = universechoices[universekey]
        except KeyError:
            possibleuniversenames = None
        if possibleuniversenames:
            #name will be modern, other, etc
            for name in possibleuniversenames:
                universe = Universe.objects.get(name = name)
                newtag.universes.add(universe)


        #debug: only do one tag
        # return

    return



def deletetags():
    filename = input('file name: ')
    filename = filename.replace('.csv','')
    filepath = importdir + filename + '.csv'

    try:
        csvfile = open(filepath)
    except FileNotFoundError:
        print('File not found: ', filepath)
        return

    tagdict = csv.DictReader(csvfile)

    for tagdata in tagdict:
        try:
            tag = Tag.objects.get(name = tagdata['Tag'].lower())
            print('delete: ' + tagdata['Tag'].lower())
            tag.delete()
        except:
            print('**tag ' + tagdata['Tag'].lower() + ' does not exist**')

