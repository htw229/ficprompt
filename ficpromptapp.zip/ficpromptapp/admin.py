from django.contrib import admin
from django import forms
from django.db import models
import suitwidgets as widgets

from ficpromptapp.models import Plot, Plotline, Setting, Universe

from smart_selects.db_fields import ChainedForeignKey, ChainedManyToManyField

from django.core.exceptions import ObjectDoesNotExist

import ficpromptapp.models as model

def make_active(modeladmin, request, queryset):
    queryset.update(active=True)
make_active.short_description = "Make Active"

def make_inactive(modeladmin, request, queryset):
    queryset.update(active=False)
make_inactive.short_description = "Make Inactive"


class UniverseAdmin(admin.ModelAdmin):
    list_display = ['pk', 'name', 'frequency']
    list_filter = [
        'frequency',
    ]
    actions = [make_active, make_inactive]

class SettingAdmin(admin.ModelAdmin):
    list_display = ['pk', 'name', 'getuniverses', 'frequency']
    list_filter = [
        'frequency',
    ]
    actions = [make_active, make_inactive]

    suit_form_includes = (
        ('settingadmintestlink.html', 'top', ''),
    )

    fieldsets = (
        (None, {
            'fields': (
                'name',
                'frequency',
                'universes',
                'fluff',
                'angst',
                'tags',
                'roles',
            ),
        }),
    )

    def getuniverses(self, obj):
        s = ' ,'.join([universe.name for universe in obj.universes.all()])
        return s
    getuniverses.short_description = 'universes'

class PlotlineAdmin(admin.ModelAdmin):
    list_display = ['pk', 'name', 'getsettings', 'frequency']
    list_filter = [
        'frequency',
    ]
    actions = [make_active, make_inactive]

    suit_form_includes = (
        ('plotlineadmintestlink.html', 'top', ''),
    )

    def getsettings(self, obj):
        s = ' ,'.join([setting.name for setting in obj.settings.all()])
        return s
    getsettings.short_description = 'settings'

class SynonymAdmin(admin.ModelAdmin):
    list_display = ['name', 'synonyms']
    list_filter = ['name']
    actions = [make_active, make_inactive]


class TagAdmin(admin.ModelAdmin):
    list_display = ['pk', 'name', 'gettagtype', 'chubbyprompt', 'getsettings', 'getuniverses', 'getrelationshipstatuses', 'frequency']
    list_filter = [
        'active',
        'tagtype',
        'settings',
        'universes',
        'frequency',
        'chubbyprompt',
    ]
    actions = [make_active, make_inactive]

    fieldsets = (
        (None, {
            'fields': (
                'name',
                'active',
                'tagtype',
                'frequency',
                'fluff',
                'angst',
                'chubbyprompt',
                'universes',
                'settings',
                'relationshipstatuses',
                'tags',
            ),
        }),
    )


    def gettagtype(self, obj):
        try:
            s = obj.tagtype.name
        except:
            s = ''
        return s
    gettagtype.short_description = ' tagtype'

    def getsettings(self, obj):
        s = ', '.join([setting.name for setting in obj.settings.all()])
        return s
    getsettings.short_description = ' settings'

    def getuniverses(self, obj):
        s = ', '.join([universe.name for universe in obj.universes.all()])
        return s
    getuniverses.short_description = ' universes'

    def getrelationshipstatuses(self, obj):
        s = ', '.join([relationshipstatus.name for relationshipstatus in obj.relationshipstatuses.all()])
        return s
    getrelationshipstatuses.short_description = ' relationshipstatuses'



#used in wgplotadmin
class PlotForm(forms.ModelForm):
    class Meta:
        widgets = {
            'summarytext' : forms.TextInput(),
            # 'settings' : forms.CheckboxSelectMultiple(),
        }

    # def clean(self):
    #     cleaned_data = super(PlotForm, self).clean()
    #     plotlines = cleaned_data.get("plotlines")
    #     settings = cleaned_data.get("settings")
    #     universes = cleaned_data.get("universes")

    #     # can have settings without a corresponding plotline
    #     # cannot have plotline without a corresponding setting

    #     # get plotlines
    #     # see if setting obj in plotline
    #     #

    #     # for setting in settings:
    #         # if plotlines.filter(settings__pk = setting.pk):
    #         # if not plotlines.settings_set.filter(pk = setting.pk).exists():
    #         #     self.add_error('settings', 'setting not in plotlines' + str(setting.pk))

    #     # for setting in settings.all():
    #     #     self.add_error('plotlines', setting)
    #     #     self.add_error('plotlines', setting.universes)

    #     self.data['name'] = 'hello'
    #     self.data['settings'] = Setting.objects.all()
    #     self.add_error('plotlines', self.data['settings'])

    # def clean_settings(self):
    #     plotlines = self.cleaned_data.get('plotlines')
    #     settings = []

    #     self.add_error('settings', plotlines)

    #     if plotlines:
    #         for plotline in plotlines:
    #             p = Plotline.objects.get(pk = plotline.pk)
    #             self.add_error('settings', p)
    #             self.add_error('settings', plotline.pk)
    #             for setting in Setting.objects.all():
    #                 if setting in p:
    #                     settings.append(setting)

        # return settings

class PlotAdmin(admin.ModelAdmin):
    save_as = True
    list_display = [
        'pk',
        'active',
        'name',
        'chubbyprompt',
        'getplotlines',
        'getsettings',
        # 'getuniverses',
        'frequency',
]
    list_filter = [
        'active',
        'chubbyprompt',
        'plotlines',
        'settings',
        # 'universes',
        'frequency',
    ]
    search_fields = ('name', 'text', 'tags', 'options_A', 'options_B', 'options_C', 'variableoptions_D', 'variableoptions_E', 'variableoptions_F')
    actions = [make_active, make_inactive]

    form = PlotForm
    suit_form_includes = (
        ('plotadmintestlink.html', 'top', ''),
    )

    formfield_overrides = {
        models.TextField: {
            'widget': widgets.AutosizedTextarea(
                attrs={
                    'class': '',
                    'style': 'max-height: 500px; width: 95%;',
                },
            ),
        },
        models.ManyToManyField: {
            'widget' : forms.SelectMultiple(
                attrs={
                    'size':'8',
                }
            ),
        },
    }

    fieldsets = (
        (None, {
            'fields': (
                'name',
                'active',
                'frequency',
            )
        }),
        ( 'universe/setting/plotline', {
            'fields': (
                'universes',
                'settings',
                'plotlines',
            ),
            'classes': ('collapse',),
        }),
        ('genre/content', {
            'fields': (
                'fluff',
                'angst',
                'addgenplotdevice',
                'addromanceplotdevice',
                'relationshipstatuses',
            ),
            'classes': ('collapse',),
        }),
        ('roles/tags', {
            'fields': (
                'tags',
                'requiredrole_char1',
                'requiredrole_char2',
                'roleselection',
                'roles',
            ),
            'classes': ('collapse',),
        }),
        ('chubby', {
            'fields': (
                'chubbyprompt',
                'addchubbyplotdevice',
                'chubby_char1',
                'chubby_char2',
            ),
            'classes': ('collapse',),
        }),
        ('Text', {
            'fields': ('text',),
            'classes': ('full-width',),
        }),
        ('Static - [optA]', {
            'fields': ('options_A',),
            'classes': ('full-width',),
        }),
        ('Static - [optB]', {
            'fields': ('options_B',),
            'classes': ('full-width',),
        }),
        ('Static - [optC]', {
            'fields': ('options_C',),
            'classes': ('full-width',),
        }),
        ('Dynamic - [optD]', {
            'fields': ('variableoptions_D',),
            'classes': ('full-width',),
        }),
        ('Dynamic - [optE]', {
            'fields': ('variableoptions_E',),
            'classes': ('full-width',),
        }),
        ('Dynamic - [optF]', {
            'fields': ('variableoptions_F',),
            'classes': ('full-width',),
        }),
    )

    def getplotlines(self, obj):
        s = ', '.join([plotline.name for plotline in obj.plotlines.all()])
        return s
    getplotlines.short_description = ' plotlines'

    def getsettings(self, obj):
        s = ', '.join([setting.name for setting in obj.settings.all()])
        return s
    getsettings.short_description = ' settings'

    # def getuniverses(self, obj):
    #     s = ', '.join([universe.name for universe in obj.universes.all()])
    #     return s
    # getuniverses.short_description = ' universes'



class WGPlotAdmin(admin.ModelAdmin):
    actions_on_top = True

    #listview
    list_display = ['pk', 'active', 'summarytext', 'plot_frequency']
    list_filter = [
        'active',
        'plot_frequency',
        'cause_and_effect',
        'gaintype_unintentional',
        'gaintype_intentional',
        'gaintype_noweightgain',
        'is_mutual',
    ]
    search_fields = ('summarytext', 'text', 'options_A', 'options_B', 'options_C')
    actions = [make_active, make_inactive]

    #edit

    suit_form_includes = (
        ('promptchangeform_bcklink.html', 'top', ''),
    )


    form = PlotForm
    formfield_overrides = {
        models.CharField: {'widget': forms.TextInput(attrs={'size':'20'})},
        models.TextField: {'widget': widgets.AutosizedTextarea(attrs={
            'class': '',
            'style': 'max-height: 500px; width: 95%;',
        }),},
    }
    fieldsets = (
        (None, {
            'fields': (
                'summarytext',
                'active',
                'plot_frequency',
            )
        }),
        ( 'Meta', {
            'fields': (
                'type_of_relationship',
                'cause_and_effect',
                'gaintype_unintentional',
                'gaintype_intentional',
                'gaintype_noweightgain',
                'is_mutual',
            ),
            'classes': ('collapse',),
        }),
        ('Tags', {
            'fields': (
                'freeform_tags',
                'cause_tags',
                'randomthings_tags',
            ),
            'classes': ('collapse',),
        }),
        ('Text', {
            'fields': ('text',),
            'classes': ('full-width',),
        }),
        ('[optA]', {
            'fields': ('options_A',),
            'classes': ('full-width',),
        }),
        ('[optB]', {
            'fields': ('options_B',),
            'classes': ('full-width',),
        }),
        ('[optC]', {
            'fields': ('options_C',),
            'classes': ('full-width',),
        }),
    )


### BETA ###
class bWGPlotAdmin(admin.ModelAdmin):
    actions_on_top = True
    actions_on_bottom = True

    #listview
    list_display = ['pk', 'active', 'summarytext', 'plot_frequency']
    list_filter = [
        'active',
        'plot_frequency',
        'cause_and_effect',
        'gaintype_unintentional',
        'gaintype_intentional',
        'gaintype_noweightgain',
        'is_mutual',
    ]
    search_fields = ('summarytext', 'text', 'options_A', 'options_B', 'options_C')
    actions = [make_active, make_inactive]

    #edit

    suit_form_includes = (
        ('promptchangeform_bcklink.html', 'top', ''),
    )


    form = PlotForm
    formfield_overrides = {
        models.CharField: {'widget': forms.TextInput(attrs={'size':'20'})},
        models.TextField: {'widget': widgets.AutosizedTextarea(attrs={
            'class': '',
            'style': 'max-height: 500px; width: 95%;',
        }),},
    }
    fieldsets = (
        (None, {
            'fields': (
                'summarytext',
                'active',
                'plot_frequency',
            )
        }),
        ( 'Meta', {
            'fields': (
                'type_of_relationship',
                'cause_and_effect',
                'gaintype_unintentional',
                'gaintype_intentional',
                'gaintype_noweightgain',
                'is_mutual',

                'must_increase_startweight_1',
                'startweight_magnitude_1',
                'gain_magnitude_1',

                'must_increase_startweight_2',
                'startweight_magnitude_2',
                'gain_magnitude_2',
            ),
            'classes': ('collapse',),
        }),
        ('Tags', {
            'fields': (
                'freeform_tags',
                'cause_tags',
                'randomthings_tags',
            ),
            'classes': ('collapse',),
        }),
        ('Text', {
            'fields': ('text',),
            'classes': ('full-width',),
        }),
        ('[optA]', {
            'fields': ('options_A',),
            'classes': ('full-width',),
        }),
        ('[optB]', {
            'fields': ('options_B',),
            'classes': ('full-width',),
        }),
        ('[optC]', {
            'fields': ('options_C',),
            'classes': ('full-width',),
        }),
    )




#ficprompts register
admin.site.register(model.TagType)
admin.site.register(model.Tag, TagAdmin)
admin.site.register(model.Universe, UniverseAdmin)
admin.site.register(model.Setting, SettingAdmin)
admin.site.register(model.Plotline, PlotlineAdmin)
admin.site.register(model.Plot, PlotAdmin)
admin.site.register(model.RelationshipStatus)
admin.site.register(model.Synonym, SynonymAdmin)
admin.site.register(model.RoleSelection)

#chubbyprompts register
admin.site.register(model.WGTheme)
admin.site.register(model.WGPlot, WGPlotAdmin)
# admin.site.register(model.WGCause)
# admin.site.register(model.Tag)

#chubbyprompts beta
admin.site.register(model.bWGPlot, bWGPlotAdmin)
admin.site.register(model.bSynonyms)
admin.site.register(model.bTag)


