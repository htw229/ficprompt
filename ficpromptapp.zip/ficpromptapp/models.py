from django.db import models
from django.utils.safestring import mark_safe
from smart_selects.db_fields import ChainedForeignKey, ChainedManyToManyField

# import uuid
# import random
from weightgain import GAIN_TYPES
import appsettings

br = '<br>'

# FREQUENCY_CHOICES = [f for f in FREQUENCIES.items()]

ANGST_CHOICES = [
    ('ANY', 'ANY'),
    ('MUST_HAVE','prompt MUST include angst'),
    ('CANNOT_HAVE','prompt CANNOT include angst'),
]

FLUFF_CHOICES = [
    ('ANY', 'ANY'),
    ('MUST_HAVE','prompt MUST include fluff'),
    ('CANNOT_HAVE','prompt CANNOT include fluff'),
]

MARKUP_INSTRUCTIONS = " markup: [1] [1HE] [1LASTNAME] [1ROLE] [c]" + br + \
    "{ A } { A | B | C } {1 | maleitem | femaleitem}" + br + br + \
    "<1-10>" + br + br + \
    "$synonym / $a^synonym, [1ROLE] / [1AROLE] to precede by 'a'/'an' / [1THEROLE] for 'The'"

### CUSTOM FIELDS ###
class FrequencyField(models.CharField):
    """ charfield that selects frequency of object, as defined
        in appsettings """

    FREQUENCY_CHOICES = [(f[0], f[0]) for f in appsettings.FREQUENCIES.items()]

    def __init__(self, *args, **kwargs):
        kwargs = {
            'max_length': 50,
            'choices': self.FREQUENCY_CHOICES,
            'default': 'COMMON',
        }

        super(FrequencyField, self).__init__(*args, **kwargs)

class NameField(models.CharField):
    """ charfield that contains unique object name
        for purpose of str() and identification """

    def __init__(self, *args, **kwargs):
        kwargs = {
            'max_length': 200,
            'unique': True,
            'default': '',
        }

        super(NameField, self).__init__(*args, **kwargs)

class TagsField(models.TextField):
    """ textfield containing object's tags """

    def __init__(self, *args, **kwargs):
        kwargs = {
            'help_text': "separate by linebreak; only one will be chosen at a time;" + \
                "* required, + common, - rare, & limitreuse" + br + br + MARKUP_INSTRUCTIONS + \
                br + br + "* for AUs, || on same line to choose only one of tags, && to break up into 2+ tags",
            'blank': True,
        }

        super(TagsField, self).__init__(*args, **kwargs)

class RolesField(models.TextField):
    def __init__(self, *args, **kwargs):
        kwargs = {
            'verbose_name': ' roles',
            'help_text': "LOWERCASE unless require uppercase" + br + br + \
                "* required by either; & can choose twice; + common; - rare" +  br + br + \
                "{c | male | female}; if using markup, must have space between, ex: * {c | malerole | femalerole}" +  br + br + \
                "can combine, ex: 1&+" + br + br + MARKUP_INSTRUCTIONS + br + br + "separate options by linebreak; <none> = placeholder for blank item" +
                br + br + '* do not use numbers "1" or "2" in actual text',


            'blank': True,
        }

        super(RolesField, self).__init__(*args, **kwargs)



### CUSTOM MODELS ###
class NameFreqTagsModel(models.Model):
    name = NameField(' name')

    angst = models.CharField(
        " angst",
        help_text = mark_safe("* ANY/ANY will allow any prompt" + br \
            + "* keep possibilities as open as possible and " \
            + "use these limitations to prevent jarring conflicts"),
        max_length = 50,
        choices = ANGST_CHOICES,
        default='ANY',
    )

    fluff = models.CharField(
        " fluff",
        help_text = "",
        max_length = 50,
        choices = FLUFF_CHOICES,
        default='ANY',
    )

    frequency = FrequencyField(' frequency')
    tags = TagsField(' tags')

    class Meta:
        abstract = True

    def __str__(self):
        s = self.name + ' [' + str(self.pk) + ']'
        return s



#######################################
###         FICPROMPTS              ###
#######################################

ROLE_SELECTION_CHOICES = (
    ('NONE', 'NONE'),
    ('plot', 'Plot'),
    ('plotline', 'Plotline'),
    ('setting', 'Setting'),
    ('universe', 'Universe'),
)



class Universe(NameFreqTagsModel):
    active = models.BooleanField(
        ' active',
        help_text = '',
        default = True,
    )

    # does not need roles (ie highschool universe also has setting, modern adult also has setting...)
    # roles = RolesField()

    class Meta:
        ordering = ['name']


class Setting(NameFreqTagsModel):
    active = models.BooleanField(
        ' active',
        help_text = '',
        default = True,
    )

    universes = models.ManyToManyField(
        Universe,
        help_text = "selects setting that matches any of the universes" + br + br \
            + "if blank, can be any",
        blank=True,
        null = True,
    )

    roles = RolesField()

    # def __str__(self):
    #     s = self.name
    #     s += ' ('
    #     s += ','.join([universe.name for universe in self.universes.all()])
    #     s += ')'
    #     return s

    class Meta:
        ordering = ['name']


class RoleSelection(models.Model):
    name = models.CharField(
        ' name',
        help_text = "model object it represents",
        choices = ROLE_SELECTION_CHOICES,
        default = 'NONE',
        max_length = 200,
        unique = True,
    )

    rank = models.IntegerField(
        ' rank',
        help_text = "used to determine order to required roles (*) " + \
            "that character's role is selected from this object" + br + br + \
            " 1 = highest priority",
        choices = (
            (1, '1'),
            (2, '2'),
            (3, '3'),
            (4, '4'),
            (5, '5'),
        ),
    )

    frequency = FrequencyField(
        ' frequency',
        help_text = "used to determine relative frequency for optional roles ",
    )

    def __str__(self):
        s = self.name
        return s



class Plotline(NameFreqTagsModel):
    active = models.BooleanField(
        ' active',
        help_text = '',
        default = True,
    )

    universes = models.ManyToManyField(
        Universe,
        help_text = "choose from universe and/or setting" + br + br \
            + "selects plotline that matches ANY of the three" + br + br \
            + "if all blank, can be any",
        blank=True,
        null = True,
    )

    settings = models.ManyToManyField(
        Setting,
        blank=True,
        null = True,
    )

    # settings = ChainedManyToManyField(
    #     Setting,
    #     chained_field = 'universes',
    #     chained_model_field = 'universes',
    #     help_text = 'if none selected, can apply to any universe',
    #     auto_choose = False,
    #     blank=True,
    #     null=True,
    # )

    roles = RolesField()

    # def __str__(self):
    #     s = self.name
    #     # s += ' | '
    #     # s += ', '.join([setting.name for setting in self.settings.all()])
    #     # s += '  (' + self.frequency.lower() + ')'
    #     return s

    class Meta:
        ordering = ['name']

class RelationshipStatus(NameFreqTagsModel):
    class Meta:
        ordering = ['name']


chubbycharacterchoices = (
    ('ALWAYS', 'ALWAYS'),
    ('OPTIONAL', 'OPTIONAL'),
    ('NEVER', 'NEVER'),
)

class Plot(NameFreqTagsModel):

    universes = models.ManyToManyField(
        Universe,
        help_text = "choose from universe and/or setting and/or plotline" + br + br \
            + "selects plot that matches ANY of the three" + br + br \
            + "if all blank, can be any",
        blank=True,
        null = True,
    )

    settings = models.ManyToManyField(
        Setting,
        help_text = "",
        blank=True,
        null = True,
    )

    plotlines = models.ManyToManyField(
        Plotline,
        help_text = "",
        blank=True,
        null = True,
    )

    active = models.BooleanField(
        ' active',
        help_text = '',
        default = True,
    )

    addgenplotdevice = models.BooleanField(
        ' addgenplotdevice',
        help_text = 'can add a gen plot device tag',
        default = True,
    )

    addromanceplotdevice = models.BooleanField(
        ' addromanceplotdevice',
        help_text = 'can add a romance plot device tag',
        default = True,
    )


    relationshipstatuses = models.ManyToManyField(
        RelationshipStatus,
        help_text = "plot works with these starting relationship statuses; " + \
            "if none selected, can work with any; " + \
            "does not have to be a romanceplot",
        blank=True,
        null = True,
    )

    requiredrole_char1 = models.CharField(
        " [1] required role",
        help_text="if [1] has required role, put it here",
        max_length=200,
        blank = True,
        null = True,
    )

    requiredrole_char2 = models.CharField(
        " [2] required role",
        help_text="if [2] has required role, put it here",
        max_length=200,
        blank = True,
        null = True,
    )

    roleselection = models.ManyToManyField(
        RoleSelection,
        help_text = "where to get roles for character 1" + br + \
            "no options selected is the same as all options selected" + br + br,
        blank=True,
        null = True,
        related_name = 'role_objects_char1',
    )

    # change to same for both characters
    # roleselection_char2 = models.ManyToManyField(
    #     RoleSelection,
    #     help_text = "where to get roles for character 1" + br + \
    #         "no options selected is the same as all options selected" + br + br,
    #     blank=True,
    #     null = True,
    #     related_name = 'role_objects_char2',
    # )

    roles = RolesField()

    text = models.TextField(
        " text",
        help_text= 'separate options by #;' + MARKUP_INSTRUCTIONS,
        blank=True,
    )

    options_A = models.TextField(
        " options_A [optA]",
        help_text='same choice used in tags, scene, text; separate options by linebreak; <+> common; <-> rare' + \
            '<none> = placeholder for blank item;',
        blank=True,
    )

    options_B = models.TextField(
        " options_B [optB]",
        blank=True,
    )

    options_C = models.TextField(
        " options_C [optC]",
        blank=True,
    )

    variableoptions_D = models.TextField(
        " variableoptions_D [optD]",
        help_text = "different choice used every time it's called, then loops; separate options by linebreak; <+> common; <-> rare" + \
            '<none> = placeholder for blank item;',
        blank=True,
    )

    variableoptions_E = models.TextField(
        " variableoptions_E [optE]",
        blank=True,
    )

    variableoptions_F = models.TextField(
        " variableoptions_F [optF]",
        blank=True,
    )

    chubbyprompt = models.BooleanField(
        ' chubbyprompt',
        help_text = '',
        default = False,
    )

    addchubbyplotdevice = models.BooleanField(
        ' addchubbyplottag',
        help_text = 'true if can add chubby plot tag (ie freshman 15 -- which would also be dependent on college au setting/plotline); ' + \
        'can always add generic chubby tags (ie button popping)',
        default = True,
    )

    chubby_char1 = models.CharField(
        " chubby_char1: chubby [1]",
        help_text="",
        max_length=10,
        choices = chubbycharacterchoices,
        default = 'OPTIONAL',
    )

    chubby_char2 = models.CharField(
        " chubby_char2: chubby [2]",
        help_text="",
        max_length=10,
        choices = chubbycharacterchoices,
        default = 'ALWAYS',
    )

    # chubbyprompt = models.BooleanField(
    #     ' chubbyprompt',
    #     help_text = '(recommend making common or very common if true)',
    #     default = False,
    # )

    def getoptionfields(self):
        optionfields = {}
        optionfields['static'] = (('options_A', '[optA]'), ('options_B', '[optB]'), ('options_C', '[optC]'))
        optionfields['variable'] = (('variableoptions_D', '[optD]'), ('variableoptions_E', '[optE]'), ('variableoptions_F', '[optF]'))

        return optionfields

    def save(self, *args, **kwargs):
        # all chubby prompts must have fluff
        if self.chubbyprompt == True:
            self.fluff = 'MUST_HAVE'

        super(Plot, self).save(*args, **kwargs)

    class Meta:
            ordering = ('name',)







class TagType(models.Model):
    name = NameField(
        ' name',
        help_text = "(hardcoded in appsettings.TAG_ORDER list)" ,
    )

    freeform = models.BooleanField(
        ' freeform',
        help_text = '',
        default = True,
    )

    chanceoftagtype = models.DecimalField(
        " chance of tag type",
        help_text = " 0.00-1.00, higher number = greater chance of inclusion",
        max_digits = 3,
        decimal_places = 2,
        default = 0.50,
    )

    chanceofsecondtagtype = models.DecimalField(
        " chance of second of same tag type",
        help_text = " 0.00-1.00, higher number = greater chance of inclusion",
        max_digits = 3,
        decimal_places = 2,
        default = 0.00,
    )

    requiredplotfield = models.CharField(
        " required plot field",
        help_text = " require field in plot object to be True",
        max_length = 50,
        default = '',
        blank=True,
        null= True,
    )

    angstorfluff = models.CharField(
        " require angst or fluff",
        help_text = "forces angst required/fluff not allowed or opposite on Tag object save",
        max_length = 50,
        choices = [
            ('ANY', 'ANY'),
            ('ANGST','prompt can ONLY include angst'),
            ('FLUFF','prompt can ONLY include fluff'),
        ],
        default='ANY',
    )

    def __str__(self):
        return self.name

    class Meta:
            ordering = ('name',)


class Tag(NameFreqTagsModel):
    active = models.BooleanField(
        ' active',
        help_text = '',
        default = True,
    )

    tagtype = models.ForeignKey(
        TagType,
        on_delete=models.CASCADE,
        blank=True,
        null= True,
    )

    universes = models.ManyToManyField(
        Universe,
        blank=True,
        null = True,
    )

    settings = ChainedManyToManyField(
        Setting,
        chained_field = 'universes',
        chained_model_field = 'universes',
        help_text = 'if none selected, can apply to any setting',
        blank=True,
        null = True,
    )

    relationshipstatuses = models.ManyToManyField(
        RelationshipStatus,
        help_text = "tag works with these starting relationship statuses; " + \
            "if none selected, can work with any; ",
        blank=True,
        null = True,
    )

    chubbyprompt = models.BooleanField(
        ' chubbyprompt',
        help_text = '(recommend making common or very common if true)',
        default = False,
    )

    def save(self, *args, **kwargs):
        if self.tagtype in TagType.objects.filter(angstorfluff = 'ANGST'):
            self.fluff = 'CANNOT_HAVE'
            self.angst = 'MUST_HAVE'
        elif self.tagtype in TagType.objects.filter(angstorfluff = 'FLUFF'):
            self.fluff = 'MUST_HAVE'
            self.angst = 'CANNOT_HAVE'

        super(Tag, self).save(*args, **kwargs)

    def __str__(self):
        return self.name

    class Meta:
        ordering = ['tagtype', 'name']


class Synonym(models.Model):
    name = models.CharField(
        " name",
        help_text = "in prompt, use $name to retrieve synonym",
        max_length=100,
        default = 'name',
        unique=True,
    )

    # markuptext = models.CharField(
    #     " markuptext",
    #     help_text = "in prompt, use [name] to retrieve synonym",
    #     max_length=100,
    #     default = 'name',
    #     # unique=True,
    # )

    synonyms = TagsField(' synonyms')

    class Meta:
        ordering = ['name']



#######################################
###         CHUBBYPROMPTS           ###
#######################################

class WGPlot(models.Model):
    active = models.BooleanField(
        default=False,
    )

    FREQUENCY_CHOICES = (
        ('VERY_COMMON', 'VERY_COMMON'),
        ('COMMON', 'COMMON'),
        ('RARE', 'RARE'),
    )

    plot_frequency = models.CharField(
        " plot_frequency",
        help_text="use 'very common' for common occurances without recognizable features (eg oblivious to weight gain);" + \
            "use 'rare' for specific and recognizable plots (eg mall santa or dialogue)",
        max_length=50,
        choices=FREQUENCY_CHOICES,
        default='COMMON',
    )



    MUTUAL_CHOICES = (
        ('NO','NO: only [1] gains'),
        ('YES','YES: both [1] and [2] gain'),
        ('OPTIONAL','OPTIONAL: one or both can gain'),
    )
    is_mutual = models.CharField(
        " is_mutual",
        help_text="",
        max_length=10,
        choices=MUTUAL_CHOICES,
        default='NO',
    )

    CAUSE_CHOICES = (
        ('CAUSE AND EFFECT',"CAUSE AND EFFECT"),
        ('CAUSE',"CAUSE"),
        ('EFFECT','EFFECT'),
    )
    cause_and_effect = models.CharField(
        " cause_and_effect",
        help_text = "CAUSE AND EFFECT: contains cause and consequences of weight gain |" \
            + "CAUSE: contains cause of weight gain but not consequences |" \
            + "EFFECT: contains consequences of weight gain but not cause",
        max_length=50,
        choices=CAUSE_CHOICES,
        default='CAUSE AND EFFECT',
    )

    gaintype_unintentional = models.BooleanField(
        " gaintype_unintentional",
        help_text='unintentional/accidential/oblivious weight gain',
        default=False,
    )

    gaintype_intentional = models.BooleanField(
        " gaintype_intentional",
        help_text='intentional/purposeful/feeding/stuffing',
        default=False,
    )

    gaintype_noweightgain = models.BooleanField(
        " gaintype_noweightgain",
        help_text='no weight gain/always chubby',
        default=False,
    )

    RELATIONSHIP_CHOICES = (
        ('NEW','NEW'),
        ('ESTABLISHED','ESTABLISHED'),
        ('EITHER','EITHER'),
    )
    type_of_relationship = models.CharField(
        " type_of_relationship",
        help_text='',
        max_length=15,
        choices=RELATIONSHIP_CHOICES,
        default='NEW',
    )

    summarytext = models.TextField(
        " summarytext",
        help_text="",
        default='',
        blank=True,
    )

    freeform_tags = models.TextField(
        " freeform_tags",
        help_text='separate by linebreaks; *tag = required',
        blank=True,
    )

    cause_tags = models.TextField(
        " cause_tags",
        help_text='one is chosen if this is a cause for another plot',
        blank=True,
    )

    randomthings_tags = models.TextField(
        " randomthings_tags",
        help_text='one may be randomly chosen as tag for another plot',
        blank=True,
    )

    text = models.TextField(
        " text",
        help_text= """[1] [1HE] [1LASTNAME] [1 | maleitem | femaleitem] [2:5]
            [1STARTWEIGHT] [1WEIGHT|SMALL|ROUND] [POUNDS|MEDIUM|EXACT]
            [SYNONYM] { A } { A | B | C }""",
        blank=True,
    )

    options_A = models.TextField(
        " options_A [optA]",
        help_text='separate options by linebreak',
        blank=True,
    )

    options_B = models.TextField(
        " options_B [optB]",
        help_text='separate options by linebreak',
        blank=True,
    )

    options_C = models.TextField(
        " options_C [optC]",
        help_text='separate options by linebreak',
        blank=True,
    )


    def __str__(self):
        s = []
        if not self.active:
            s.append('*inactive*')
        s.extend([
            self.pk,
            self.summarytext,
            self.plot_frequency,
        ])

        string = ''
        if self.gaintype_unintentional:
            string += '+unintentional '
        if self.gaintype_intentional:
            string += '+intentional '
        if self.gaintype_noweightgain:
            string += '+noweightgain '

        s.append(string)
        s.append('mutual: ' + self.is_mutual)

        out = ' | '.join([str(x) for x in s])
        return out

    def is_active(self):
        if not self.gaintype_unintentional and not self.gaintype_intentional and not self.gaintype_noweightgain:
            return False
        else:
            return self.active

    def gettextfieldnames(self):
        return ['text', 'freeform_tags', 'cause_tags', 'randomthings_tags']

    def getoptionfieldnames(self):
        return ['options_A', 'options_B', 'options_C']



class WGTheme(models.Model): #this table can only be production, not beta or links won't work
    name = models.CharField(
        "name",
        max_length=200,
    )

    freeform_tags = models.TextField(
        "freeform_tags",
        help_text='or=||,and=new line',
        blank=True,
    )

    def __str__(self):
        return self.name



#BETA#

class bWGPlot(models.Model):
    active = models.BooleanField(
        default=False,
    )

    FREQUENCY_CHOICES = (
        ('VERY_COMMON', 'VERY_COMMON'),
        ('COMMON', 'COMMON'),
        ('RARE', 'RARE'),
    )

    plot_frequency = models.CharField(
        " plot_frequency",
        help_text="use 'very common' for common occurances without recognizable features (eg oblivious to weight gain);" + \
            "use 'rare' for specific and recognizable plots (eg mall santa or dialogue)",
        max_length=50,
        choices=FREQUENCY_CHOICES,
        default='COMMON',
    )


    MUTUAL_CHOICES = (
        ('NO','NO: only [1] gains/is chubby'),
        ('YES','YES: both [1] and [2] gain/are chubby'),
        ('OPTIONAL','OPTIONAL: [1] +/- [2] gain/are chubby'),
    )
    is_mutual = models.CharField(
        " is_mutual",
        help_text="if OPTIONAL, [2] may start chubby but usually doesn't gain weight",
        max_length=10,
        choices=MUTUAL_CHOICES,
        default='OPTIONAL',
    )

    CAUSE_CHOICES = (
        ('CAUSE AND EFFECT',"CAUSE AND EFFECT"),
        ('CAUSE',"CAUSE"),
        ('EFFECT','EFFECT'),
    )
    cause_and_effect = models.CharField(
        " cause_and_effect",
        help_text = "CAUSE AND EFFECT: contains cause and consequences of weight gain |" \
            + "CAUSE: contains cause of weight gain but not consequences |" \
            + "EFFECT: contains consequences of weight gain but not cause",
        max_length=50,
        choices=CAUSE_CHOICES,
        default='CAUSE AND EFFECT',
    )

    gaintype_unintentional = models.BooleanField(
        " gaintype_unintentional",
        help_text='unintentional/accidential/oblivious weight gain',
        default=False,
    )

    gaintype_intentional = models.BooleanField(
        " gaintype_intentional",
        help_text='intentional/purposeful/feeding/stuffing',
        default=False,
    )

    gaintype_noweightgain = models.BooleanField(
        " gaintype_noweightgain",
        help_text='no weight gain/always chubby',
        default=False,
    )


    can_calculate_gain_1 = models.BooleanField(
        " can_calculate_gain_1",
        help_text="[1] qualifies for automatic weight calculations",
        default=False,
    )

    can_calculate_gain_2 = models.BooleanField(
        " can_calculate_gain_2",
        help_text="[2] qualifies for automatic weight calculations",
        default=False,
    )


    must_increase_startweight_1 = models.BooleanField(
        " must_increase_startweight_1",
        help_text="[1] is REQUIRED to be chubby before prompt",
        default=False,
    )

    must_increase_startweight_2 = models.BooleanField(
        " must_increase_startweight_2",
        help_text="[2] is REQUIRED to be chubby before prompt",
        default=False,
    )


    MAGNITUDE_CHOICES = [
        ('NONE', 'NONE: Starting weight'),
    ]
    MAGNITUDE_CHOICES.extend([(gaintype[0], \
        gaintype[0] + ': ' + str(gaintype[1]['floor']) + ' to ' + \
        str(gaintype[1]['ceil']) + 'lb') \
        for gaintype in GAIN_TYPES.items()])

    startweight_magnitude_1 = models.CharField(
        " startweight_magnitude_1",
        help_text="magnitude to increase [1]'s weight above provided startweight",
        max_length=30,
        choices=MAGNITUDE_CHOICES,
        default='NONE',
    )

    startweight_magnitude_2 = models.CharField(
        " startweight_magnitude_2",
        help_text="magnitude to increase [2]'s weight above provided startweight",
        max_length=30,
        choices=MAGNITUDE_CHOICES,
        default='NONE',
    )


    MAGNITUDE_CHOICES[0] = ('NONE', 'NONE: No weight gain')

    gain_magnitude_1 = models.CharField(
        " gain_magnitude_1",
        help_text="magnitude of [1]'s weight gain",
        max_length=30,
        choices=MAGNITUDE_CHOICES,
        default='NONE',
    )

    gain_magnitude_2 = models.CharField(
        " gain_magnitude_2",
        help_text="magnitude of [2]'s weight gain",
        max_length=30,
        choices=MAGNITUDE_CHOICES,
        default='NONE',
    )


    RELATIONSHIP_CHOICES = (
        ('NEW','NEW'),
        ('ESTABLISHED','ESTABLISHED'),
        ('EITHER','EITHER'),
    )
    type_of_relationship = models.CharField(
        " type_of_relationship",
        help_text='',
        max_length=15,
        choices=RELATIONSHIP_CHOICES,
        default='NEW',
    )

    summarytext = models.TextField(
        " summarytext",
        help_text="",
        default='',
        blank=True,
    )

    freeform_tags = models.TextField(
        " freeform_tags",
        help_text='separate by linebreaks; *tag = required',
        blank=True,
    )

    cause_tags = models.TextField(
        " cause_tags",
        help_text='one is chosen if this is a cause for another plot',
        blank=True,
    )

    randomthings_tags = models.TextField(
        " randomthings_tags",
        help_text='one may be randomly chosen as tag for another plot',
        blank=True,
    )

    text = models.TextField(
        " text",
        help_text= """[1] [1HE] [1LASTNAME] [1 | maleitem | femaleitem] [2:5]
            [1STARTWEIGHT] [1WEIGHT|SMALL|ROUND] [POUNDS|MEDIUM|EXACT]
            [SYNONYM] { A } { A | B | C }""",
        blank=True,
    )

    options_A = models.TextField(
        " options_A [optA]",
        help_text='separate options by linebreak',
        blank=True,
    )

    options_B = models.TextField(
        " options_B [optB]",
        help_text='separate options by linebreak',
        blank=True,
    )

    options_C = models.TextField(
        " options_C [optC]",
        help_text='separate options by linebreak',
        blank=True,
    )

    def save(self, *args, **kwargs):
        if self.gain_magnitude_1 == 'NONE':
            self.can_calculate_gain_1 = False
        else:
            self.can_calculate_gain_1 = True

        if self.gain_magnitude_2 == 'NONE':
            self.can_calculate_gain_2 = False
        else:
            self.can_calculate_gain_2 = True

        # if is_mutual is optional, then it means that [2]'s gain is not detailed in plot
        # therefore, if not overriden, should startweight that's affected
        if self.is_mutual == 'OPTIONAL' and self.startweight_magnitude_2 == 'NONE' and self.gain_magnitude_2 == 'NONE':
            self.startweight_magnitude_2 = 'ANYNOTSMALL'

        super(bWGPlot, self).save(*args, **kwargs)


    def __str__(self):
        s = []
        if not self.active:
            s.append('*inactive*')
        s.extend([
            self.pk,
            self.summarytext,
            self.plot_frequency,
        ])

        string = ''
        if self.gaintype_unintentional:
            string += '+unintentional '
        if self.gaintype_intentional:
            string += '+intentional '
        if self.gaintype_noweightgain:
            string += '+noweightgain '

        s.append(string)
        s.append('mutual: ' + self.is_mutual)

        out = ' | '.join([str(x) for x in s])
        return out

    #TODO: don't use this (figure out where used and change to self.active)
    def is_active(self):
        if not self.gaintype_unintentional and not self.gaintype_intentional and not self.gaintype_noweightgain:
            return False
        else:
            return self.active

    def gettextfieldnames(self):
        return ['text']

    def gettagfieldnames(self):
        return ['freeform_tags', 'cause_tags', 'randomthings_tags']

    def getoptionfieldnames(self):
        return ['options_A', 'options_B', 'options_C']






class bSynonyms(models.Model):
    description = models.CharField(
        "description",
        max_length=500,
        blank=True,
    )

    word = models.CharField(
        "word",
        max_length=100,
    )

    synonyms = models.TextField(
        "synonyms",
        help_text='separate by linebreaks; *common',
        blank=True,
    )



    def __str__(self):
        s = self.word
        strings = self.synonyms.split('\r\n')
        s = self.description + ': ' + s + ' [' + ', '.join(strings) + ']'
        s = s[:100]
        return s

    class Meta:
        ordering = ['description']
        verbose_name_plural = "synonyms"





class bTag(models.Model):
    text = models.TextField()
    common = models.BooleanField(default=False)
    wg = models.BooleanField(default=True)

    def __str__(self):
        return self.text





# must be in same order!#
# sharedmodels = [
#     WGTheme,
# ]
# livemodels = [
#     None
# ]
# betamodels = [
#     bWGPlot, bTag
# ]

# allmodels = []
# allmodels.extend(livemodels)
# allmodels.extend(betamodels)
# allmodels.extend(sharedmodels)

backupmodels = [
    WGPlot,
    bWGPlot,
    Tag,
    bTag,
    bSynonyms,
]




