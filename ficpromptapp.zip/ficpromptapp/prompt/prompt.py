prompt = {
    'text':'',
    'tags':[],
    'logs':[],
    }

universe = None
setting = None
plotline = None
plot = None

chubby = False
fluff = False
angst = False
relationshipstatus = None

def log(*string):
    s = ''
    for substring in string:
        s += str(substring) + ' '
    prompt['logs'].append(s)

def resetprompt():
    global prompt
    prompt = {
        'text':'',
        'tags':[],
        'logs':[],
        'fluff': False,
        'angst': False,
        'chubby': False,
    }

    global universe, setting, plotline, plot
    universe, setting, plotline, plot = None, None, None, None

    global fluff, angst
    fluff, angst = False, False

    global relationshipstatus
    relationshipstatus = None


    return