import random
# import randomhelper
import ficpromptstextreplacementbeta as textreplacement #BETA


#-------------------------------------------------
#   TAGS
#-------------------------------------------------

def choose_n_items(itemlist, lowerlimit = 1, upperlimit = 2):
    """ """
    chosenitems = []

    #use randomoptiongenerator to process * + - & markup
    chooseitem = textreplacement.randomoptiongenerator(itemlist, limitreuse = True)

    n = random.randint(lowerlimit, upperlimit)
    for _ in range(n):
        try:
            chosenitems.append(next(chooseitem))
        except StopIteration:
            break

    return chosenitems


#-------------------------------------------------
#   OTHER
#-------------------------------------------------

# moved to ficpromptsbeta

# def assigncharacterorder(characters):
#     random.shuffle(characters)
#     #assign numbers
#     for i, character in enumerate(characters):
#         character['characternumber'] = str(i+1) #i=0 but first character=1

#     return characters