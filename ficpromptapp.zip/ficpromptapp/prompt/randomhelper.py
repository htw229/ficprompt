import random
import bisect

import appsettings as settings
# from bisect import bisect

def removeduplicates(seq):
    result = []
    for item in seq:
        if not item in result:
            result.append(item)
    return result

def randomtruefalse(percent="None"):
    random.seed()

    if percent == "None":
        return random.choice([True,False])

    else:
        randomvalue = random.random()
        # prompt.log('randomvalue', randomvalue)
        if randomvalue <= percent:
            return True
        else:
            return False

def chooseobjectbyfrequency(objlist, adjust_frequencies = False, adjustedweights = None):
    if len(objlist) < 1:
        return None

    weights = [settings.FREQUENCIES[obj.frequency] for obj in objlist]
    if adjust_frequencies:
        for i, _ in enumerate(adjustedweights):
            weights[i] = weights[i] * adjustedweights[i]

    total = 0
    cum_weights = []
    for w in weights:
        total += w
        cum_weights.append(total)
    x = random.random() * total
    i = bisect.bisect(cum_weights, x)
    return objlist[i]



