import random
import re

# prompt object is global, shared across modules
import prompt

# import prompthelper
import language
# import itertools


#-------------------------------------------------
#   GETPROMPT REPLACEMENT FUNCTIONS
#-------------------------------------------------

def replaceoptionsandchoices(text):
    pronounreplacementlist = getpronounreplacementlist(prompt.characters)

    text = loopreplacetext(
        text,
        replaceoptions,
        replacetextfromlist,
        replacerandomint,
        replacegenderchoice,
        replacesinglechoice,
        replacemultiplechoice,
        plot = prompt.plot,
        characters = prompt.characters,
        wrapper = '[]',
        searchreplacelist = pronounreplacementlist,
        staticoptionsreplacementlist = prompt.staticoptionsreplacementlist,
    )

    return text

def replaceoptions(text, plot, staticoptionsreplacementlist, **kwargs):

    text = loopreplacetext(
        text,
        replacetextfromlist,
        replacevariableoptions,
        searchreplacelist = staticoptionsreplacementlist,
        plot = plot,
    )

    return text

def replacevariableoptions(text, plot, **kwargs):
    optionfields = plot.getoptionfields()

    for (option_field, option_markup) in optionfields['variable']:
        optiontext = getattr(plot, option_field)
        optionlist = getlistfromlines(optiontext, linebreak = True, divider = '')
        randomoption = randomoptiongenerator(optionlist)

        while option_markup in text:
            text = text.replace(option_markup, next(randomoption), 1)

    return text


#-------------------------------------------------
#   GENERIC REPLACEMENT FUNCTIONS
#-------------------------------------------------

def loopreplacetext(text, *funs, **kwargs):
    oldtext = ''
    w = 0

    while text != oldtext:
        oldtext = text

        for fun in funs:
            text = fun(text, **kwargs)

        w += 1
        if w > 25:
            prompt.log('infinite loop: loopreplacetext!')
            break

    return text

def replacetextfromlist(text, searchreplacelist, wrapper = '', **kwargs):
    """ Replaces the tuples (search,replace) in searchreplacelist in
        the text provided. Returns text """
    # prompt.log(replacetextfromlist)

    oldtext = ''
    newtext = text

    w = 0
    while newtext != oldtext:
        oldtext = newtext

        for (searchstring, replacestring) in searchreplacelist:
            newtext = searchreplacetext(newtext, searchstring=searchstring, replacestring=replacestring, wrapper=wrapper)

        w = w + 1
        if w > 25:
            prompt.log('replacetextfromlist infinite loop!')
            break

    return newtext

def searchreplacetext(text, searchstring, replacestring, wrapper=''):
    s = text
    searchstring = encloseinwrapper(searchstring, wrapper)
    # prompt.log('searchreplacetext', s, searchstring, replacestring)
    s = s.replace(searchstring, replacestring)
    return s


#-------------------------------------------------
#   LISTS
#-------------------------------------------------

def getpronounreplacementlist(characters):
    """ Creates replacement list for all characters
        and returns list of tuples: [('1HE','he')...] """

    replacementlist = []

    for character in characters:
        characternumber = character['characternumber']
        characterpronouns = language.PRONOUNS[character['pronoun']]

        replacementlist.extend(
            [(characternumber + x, y) for (x,y) in characterpronouns]
        )

        replacementlist.extend([
            [characternumber, character['fname']],
            [characternumber + 'LASTNAME', character['lname']],
            [characternumber + 'LAST', character['lname']],
            [characternumber + 'FULLNAME', character['fname'] + ' ' + character['lname']],
            [characternumber + 'FULL', character['fname'] + ' ' + character['lname']],
        ])

        if character['role']:
            replacementlist.extend([
                [characternumber + 'ROLE', character['role']],
                [characternumber + 'THEROLE', 'the ' + character['role']],
                [characternumber + 'AROLE', addarticle(character['role'])],
            ])
        else:
            replacementlist.extend([
                [characternumber + 'ROLE', ''],
                [characternumber + 'THEROLE', ''],
                [characternumber + 'AROLE', ''],
            ])

    #couple pronouns
    boyfriends = 'couple'
    husbands = 'spouses'
    if characters[0]['pronoun'] == 'HE' and characters[1]['pronoun'] == 'HE':
        boyfriends = 'boyfriends'
        husbands = 'husbands'
    elif characters[0]['pronoun'] == 'SHE' and characters[1]['pronoun'] == 'SHE':
        boyfriends = 'girlfriends'
        husbands = 'wives'

    replacementlist.extend([
        ['12BOYFRIENDS', boyfriends],
        ['12HUSBANDS', husbands],
    ])


    return replacementlist

def getlistfromlines(text, linebreak = True, divider = ''):
    if linebreak and divider == '':
        divider = '\r\n'
    lines = [t.strip() for t in text.split(divider) if t.strip() != '']

    return lines

#-------------------------------------------------
#   CHOICES
#-------------------------------------------------

def replacesinglechoice(string, **kwargs):
    """ Randomly chooses whether to display {singlechoice} or not
        for all {singlechoice} in string
        Returns string """

    s = string
    p = re.compile(r'{([^\|{}\[\]%]*)}')

    matches = re.finditer(p,s)

    for match in matches:
        choice = match.group(1)
        r = random.choice([choice, '']).strip()
        s = s.replace(match.group(0), r)

    return s

def replacemultiplechoice(string, **kwargs):
    """ Randomly chooses which choice in {multiple|choice} to display
        for all {multiplechoice} in string
        Returns string """

    s = string

    searchstring = r'(?P<replace>{(?P<g0>[^\|{}\[\]%]*)(\|\||\|)((?P<g1>[^\|{}\[\]\[\]%]*)(\|\||\|))?((?P<g2>[^\|{}\[\]%]*)(\|\||\|))?((?P<g3>[^\|{}\[\]%]*)(\|\||\|))?((?P<g4>[^\|{}\[\]%]*)(\|\||\|))?((?P<g5>[^\|{}\[\]%]*)(\|\||\|))?((?P<g6>[^\|{}\[\]%]*)(\|\||\|))?((?P<g7>[^\|{}\[\]%]*)(\|\||\|))?((?P<g8>[^\|{}\[\]%]*)(\|\||\|))?(?P<g9>[^\|{}\[\]%]*)})'
    p = re.compile(searchstring)
    matches = re.finditer(p, s)

    for match in matches:
        mdict = match.groupdict()
        mdictkeys = [x for x in mdict.keys() if 'g' in x and mdict[x] != None]
        r = mdict[random.choice(mdictkeys)].strip()
        s = s.replace(mdict['replace'], str(r))

    return s

def replacegenderchoice(string, **kwargs):
    s = string

    # searchstring = r'{\s*%(?P<character>\d)%\s*\|\s*(?P<HE>[^|{}]*)\s*\|\s*(?P<SHE>[^\[\]{}]*)\s*}'

    # searchstring = r'{\s*(?P<character>\d)\s*\|\s*(?P<HE>[^|{}]*)\s*\|\s*(?P<SHE>[^\[\]{}]*)\s*}'
    searchstring = r'\{\s*(?P<character>\d)\s*\|\s*(?P<HE>[^|{}]*)\s*\|\s*(?P<SHE>[^\[\]{}]*)\s*\}'
    p = re.compile(searchstring)
    matches = re.finditer(p, s)

    for match in matches:
        mdict = match.groupdict()
        i = int(mdict['character']) - 1
        pronoun = kwargs['characters'][i]['pronoun']
        r = mdict[pronoun].strip()
        s = s.replace(match.group(0), str(r))

    return s

def randomoptiongenerator(optionslist, limitreuse = False, maxoptions = 50, keeprequiredmarker = False):
    """ Given a list of text, will randomly select a next option.
        Uses markup at beginning of line:
            * = required (will be selected first in order)
            + = common (will be selected at frequency of commonoptionmultiplier)
            - = uncommon
            & = if limitreuse=True, allows reuse of this line
        Yields string """

    if len(optionslist) == 0:
        return None

    pstart = r'\s*^[\*&\+\-]*'
    pend = r'[\*&\+\-]*\s*(.+)'

    commonoptionmultiplier = 20
    otheroptionmultiplier = 10
    uncommonoptionmultiplier = 8

    weightedoptions = []

    numoptions = 0

    for textitem in optionslist:
        # matchrequired = re.search(pstart + r'\*' + pend, textitem)
        # matchcommon = re.search(pstart + r'\+' + pend, textitem)
        # matchuncommon = re.search(pstart + r'\-' + pend, textitem)

        # matchcanreuse = re.search(pstart + r'\&' + pend, textitem)

        # if starts with whitespace character \s* ignore it
        matchrequired = re.search(pstart + r'\*' + pend, textitem)
        matchcommon = re.search(pstart + r'\+' + pend, textitem)
        matchuncommon = re.search(pstart + r'\-' + pend, textitem)

        matchcanreuse = re.search(pstart + r'\&' + pend, textitem)

        if matchcanreuse:
            canreuse = True
        else:
            canreuse = False

        if matchrequired:
            numoptions = numoptions + 1
            if keeprequiredmarker:
                yield '*' + matchrequired.group(1)
            else:
                yield matchrequired.group(1)
            if not canreuse:
                continue

        if matchcommon:
            weightedoptions.append({
                'text': matchcommon.group(1),
                'canreuse': canreuse,
                'weight': commonoptionmultiplier,
            })
        elif matchuncommon:
            weightedoptions.append({
                'text': matchuncommon.group(1),
                'canreuse': canreuse,
                'weight': uncommonoptionmultiplier,
            })
        else:
            if matchcanreuse:
                text = matchcanreuse.group(1)
            else:
                text = textitem
            weightedoptions.append({
                'text': text,
                'canreuse': canreuse,
                'weight': otheroptionmultiplier,
            })

    alloptions = [x for x in weightedoptions]

    w = 0

    while True:
        # prompt.log(numoptions)

        while len(weightedoptions) >= 1:
            # limit number of options yielded (used in for loops)
            numoptions = numoptions + 1
            if numoptions > maxoptions:
                return None

            weightedoptions.sort(key = lambda item: random.random() * item['weight'], reverse = True)
            if weightedoptions[0]['canreuse']:
                yield weightedoptions[0]['text']
            else:
                yield weightedoptions.pop(0)['text']

        if not limitreuse:
            #repopulate weightedoptions and loop over again
            weightedoptions = [x for x in alloptions]
        if limitreuse:
            return None

        # prevent infinite loop
        w = w + 1
        if w >= 50:
            return None




#-------------------------------------------------
#   OTHER REPLACEMENTS
#-------------------------------------------------

synonymdict = {}

def replacesynonyms(text, **kwargs):
    """ Given string and Synonym model object,
        markup:
            $synonym
            $a^synonym (if starts with a, so can determine a/an based on vowel)
        replace all synonym markups with random synonym
        ranked by priority, attempt to avoid duplicates
        Returns string with synonyms replaced """

    # prompt.log('SYNONYMS')

    Synonym = kwargs['Synonym']
    s = text

    # captures $synonym, stopping at space or non-word character
    # can have &a^synonym to start with 'a' (so can transform to 'an' if needed)
    p = re.compile(r'(\$(a\^)?([^#\s\W]*))', re.IGNORECASE)
    matches = re.finditer(p, s)

    # prompt.log('matches',[x for x in matches])

    global synonymdict


    for match in matches:
        # word = match.group(1)
        add_a = match.group(2)
        word = match.group(3)

        prompt.log('word',word)
        prompt.log('match group 0', match.group(0))
        prompt.log('match group 1', match.group(1))
        prompt.log('match group 2', match.group(2))
        prompt.log('match group 3', match.group(3))

        # if synonymdict for word exists, then get next item in list
        try:
            synonym = synonymdict[word].pop(0)
            prompt.log('synonym', synonym, 'word=', word)

        # if synonymdict for word does not exist, create it and get first item in list
        # synonymdict = {}, synonymdict[word] = [synonyms]
        except KeyError:
            synonymdict[word] = getsynonymlist(Synonym, word)
            synonym = synonymdict[word].pop(0)

            # prompt.log('keyerror - synonym', synonym, 'word=', word)

        except IndexError:
            synonymdict[word] = getsynonymlist(Synonym, word)
            synonym = synonymdict[word].pop(0)

            # synonym = 'No synonyms for ' + word
            # prompt.log('IndexError - synonymdict[word].pop(0)', synonymdict)

        # if adding 'a', make sure it is 'an' if precedes vowel
        # if synonym is another synonym, make sure add a continues
        if add_a:
            if synonym[0] == '$':
                synonym = synonym[0] + 'a^' + synonym[1:]
            else:
                synonym = addarticle(synonym)

        s = s.replace(match.group(0), synonym, 1)

        # prompt.log('s',s)

    return s


def getsynonymlist(Synonym, word):
    try:
            synonymslist = Synonym.objects.get(name__iexact = word).synonyms.split('\r\n')

    except:
        return ['SYNONYM ERROR: ' + word] * 25

    rankedsynonymslist = [synonym for synonym in randomoptiongenerator(
        synonymslist,
        limitreuse = False,
        maxoptions = 25,
    )]

    return rankedsynonymslist


def replacerandomint(string, **kwargs):
    s = string
    searchstring = r'<\s*(\d+)\s*-\s*(\d+)\s*>'
    p = re.compile(searchstring)
    matches = re.finditer(p, s)

    for match in matches:
        intrange = sorted([int(match.group(1)), int(match.group(2))])
        r = random.randint(intrange[0], intrange[1])
        s = s.replace(match.group(0), str(r))

    return s

def chooseline(text, linebreak = True, divider = ''):
    if linebreak and divider == '':
        divider = '\r\n'
    lines = [t for t in text.split(divider) if t.strip() != '']
    # prompt.log('lines', lines)

    if not len(lines) > 0:
        return ''

    tagtextgenerator = randomoptiongenerator(
        lines,
        maxoptions = 1,
    )

    for line in tagtextgenerator:
        if line == '<none>':
            line = ''
        line = line.strip(divider).strip()
        return line

    # if len(lines) > 0:
    #     line = random.choice(lines).strip(divider).strip()
    #     if line == '<none>':
    #         line = ''
    # else:
    #     line = ''

    return line


#-------------------------------------------------
#   POSTPROCESSING
#-------------------------------------------------

def linebreak_to_paragraph(text):
    return text.replace('\r\n\r\n', '</p><p>')


def titlecase(text, maxwords = 0):
    """ Capitalizes all words in string
        maintaining pre-existing caps
        and ignoring DO_NOT_CAPITALIZE list unless word is first in string
        ex. born in the USA -> Born In The USA
        Returns string """

    words = text.split()

    if maxwords and len(words) > maxwords:
        return text

    for i, word in enumerate(words):

        # capitalize first word in text even if in list
        if (i == 0 or word not in language.DO_NOT_CAPITALIZE) and word.islower():
            words[i] = words[i].title()

    text = ' '.join(words)

    return text


def capitalizenewsentences(string):
    """
        Does not work if there is html markup (i.e. <p> tags) """

    s = string

    # prompt.log('capitalizenewsentences')
    # prompt.log('old text:', repr(s))

    # Capitalize first letter of string
    p = re.compile(r'^\w')
    s = re.sub(p, lambda x: x.group(0).upper(), s)

    # Capitalize words after . ? !
    # sometimes there are spaces that aren't captured as spaces
    # so not using \s
    p = re.compile(r'(?<=[\.\?!])(?:[^\w\<\>/\"]+?)(\w)')
    s = re.sub(p, lambda x: x.group(0).upper(), s)

    # Capitalize letters after quotes
    p = re.compile(r'(?<=\")(\w)')
    s = re.sub(p, lambda x: x.group(0).upper(), s)

    # prompt.log('new text:', s)

    return s


def createparagraphs(s):
    """ create paragraphs, capitalize, add period
        Return string """

    s = '.</p><p>'.join([capitalizenewsentences(x.strip() + '.') for x in s.split('\r\n') if x != ''])
    return s


def removeduplicatepunctuation(string):
    s = string

    # remove extra whitespace
    # space between last word and end of sentence
    p = re.compile(r'(\s+)([.,?!])')
    s = re.sub(p, r"\2", s)
    # multiple spaces in row
    p = re.compile(r'[[:blank:]]{2,}')
    s = re.sub(p,' ',s)
    # whitespace after beginning quote
    p = re.compile(r'(\")([[:blank:]]+)([^\"\n]*\")')
    s = re.sub(p, r"\1\3", s)
    # whitespace before end quote
    p = re.compile(r'(\"[^\"\n]*)([[:blank:]]+)(\")')
    s = re.sub(p, r"\1\3", s)

    #remove duplicates ('..')
    p = re.compile(r'([\",.!?])\1{2,}')
    s = re.sub(p, r'\1', s)

    # manually remove duplicate punctuation
    # some of these might happen intentionally
    # for convenience in prompt writing
    duplicatepunctuation = [
        ['..', '.'],
        ['. .', '.'],
        ['.,', '.'],
        ['. ,', '.'],
        [',.', '.'],
        [', .', '.'],
        [',,', ','],
        ['?.', '?'],
        ['?,', '?'],
        ['".', '"'],
        ['",', '"'],
    ]
    for (searchstring, replacestring) in duplicatepunctuation:
        s = s.replace(searchstring, replacestring)

    s = s.lstrip(',')
    s = s.lstrip('.')
    s = s.lstrip('?')
    s = s.lstrip('!')
    s = s.strip()


    #if space between word and 's, get rid of it
    #may be intentional for convenient in prompt writing
    s = s.replace(" 's ", "'s ")


    return s


def addarticle(word):
    """ Adds a or an to beginning of word
        depending on whether first letter is vowel
        Returns string """

    try:
        if word[0] in 'aeiou':
            s = 'an ' + word
        else:
            s = 'a ' + word
    except IndexError:
        s = word

    return s

#-------------------------------------------------
#-------------------------------------------------

def encloseinwrapper(string, wrapper):
    """ Encloses 'string' in wrapper '[]'
        and returns '[string]' """

    try:
        s = wrapper[0] + string + wrapper[1]
    except IndexError:
        s = string
    return s


def n_chars(char, n):
    """ Creates string composed of repeat of same character
        char = '{', n = 3 -> s = '{{{'
        Returns string """

    s = ''
    if n > 0:
        for _ in range(n):
            s = s + char
    return s






