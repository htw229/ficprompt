import re
import random
from django.db.models import Q

import prompt
import language
import weightgain

from ficpromptapp.models import bSynonyms as Synonyms

import appsettings as settings

def replaceallprompttext(plot, characters):
    oldtext = 'old'
    newtext = 'new'
    w = 0

    while oldtext != newtext:

        oldtext = newtext

        ### optionfields first
        plot = replacevariables(plot, characters, optionfields = True)
        plot = replacechoices(plot, characters, optionfields = True)
        plot = replacetextfromlist(plot, getoptionreplacementlist(plot), wrapper='[]', loop=True)

        ### then textfields
        plot = replacevariables(plot, characters)
        plot = funcreplacetext(plot, replacesynonyms) #must be after options and variables because will capture them


        plot = replacechoices(plot, characters)

        newtext = getalltextfieldtext(plot)

        w += 1
        if w > 50:
            prompt.log('!infinite loop replacevariables()')
            break


    ### then format plot text
    plot = selectandformatplottext(plot)

    ### then clean up punctuation in textfields
    plot = funcreplacetext(plot, removeduplicatepunctuation)

    return plot


#-------------------------------------------------------------

def replacevariables(plot, characters, optionfields = False):
    """ Replaces pronoun and weight variables
        Returns plot object """

    plot = replacetextfromlist(plot, getpronounreplacementlist(characters), wrapper='[]')
    plot = replacetextfromlist(plot, getweightreplacementlist(plot, characters), optionfields=optionfields) #[] included in regex
    plot = funcreplacetext(plot, replacerandomint, optionfields = optionfields)

    return plot

def replacechoices(plot, characters, optionfields = False):
    """ Chooses results from gendered, single and multiple choices fields
        Returns plot object """

    oldtext = 'old'
    newtext = 'new'
    w = 0

    while oldtext != newtext:

        oldtext = newtext

        plot = funcreplacetext(plot, replacegenderedchoice, optionfields=optionfields, extraArgs=[characters])
        plot = funcreplacetext(plot, replacesinglechoice, optionfields=optionfields)
        plot = funcreplacetext(plot, replacemultiplechoice, optionfields=optionfields)


        newtext = getalltextfieldtext(plot, optionfields=optionfields)
        #prompt.log(w, newtext)

        w += 1
        if w > 25:
            prompt.log('!infinite loop replacevariables()')
            break

    return plot


def selectandformatplottext(plot):
    text = getattr(plot, 'text')

    #select plot text (each choice begins w/'#')
    plottextchoices = [x for x in text.split('#') if len(x) > 1]
    plottext = random.choice(plottextchoices)

    # create paragraphs, capitalize, add period
    s = '.</p><p>'.join([capitalizenewsentences(x.strip() + '.') for x in plottext.split('\r\n') if x != ''])
    # s = capitalizenewsentences(s)

    setattr(plot, 'text', s)

    return plot



#-------------------------------------------------------------


def getoptionreplacementlist(plot):
    """ Chooses random line from each optA/B/C
    and returns list of tuples: [('optA','selected option line')...] """

    optiontexts = [
        ('optA', plot.options_A),
        ('optB', plot.options_B),
        ('optC', plot.options_C),
    ]

    replacementlist = []

    for optiontext in optiontexts:
        replacementchoices = optiontext[1].split('\r\n') #split options on linebreaks
        replacementchoices = [x for x in replacementchoices if x != ''] #don't allow blank lines
        try:
            replacementchoice = random.choice(replacementchoices)
        except IndexError: #optiontext is blank
            replacementchoice = ''

        if replacementchoice == '<none>':
            replacementchoice = ''

        replacementlist.append((optiontext[0],replacementchoice))

    return replacementlist


def getpronounreplacementlist(characters):
    """ Creates replacement list for all characters
        and returns list of tuples: [('1HE','he')...] """

    replacementlist = []

    for character in characters:
        characternumber = character['characternumber']
        characterpronouns = language.PRONOUNS[character['pronoun']]

        replacementlist.extend(
            [(characternumber + x, y) for (x,y) in characterpronouns]
        )

        replacementlist.extend([
            [characternumber, character['fname']],
            [characternumber + 'LASTNAME', character['lname']],
            [characternumber + 'LAST', character['lname']],
            [characternumber + 'FULLNAME', character['fname'] + ' ' + character['lname']],
            [characternumber + 'FULL', character['fname'] + ' ' + character['lname']],
            [characternumber + 'STARTWEIGHT', character['startweight']],
            [characternumber + 'WEIGHT', character['startweight']],
        ])

    return replacementlist


def getweightreplacementlist(plot, characters):
    """ Creates replacement list for [WEIGHT] and [POUNDS]
        and returns list of tuples: [('[1|WEIGHT|XLARGE|ROUND]','280')...] """


    s = getalltextfieldtext(plot)
    p = re.compile(r'\[(?P<character>\d)?(\|)?(?P<weighttype>POUNDS|WEIGHT)\|(?P<gaintype>\w+)\|?(?P<roundtype>ROUND|EXACT)?\]')
    matches = re.finditer(p,s)

    replacementlist = []

    for match in matches:
        mdict = match.groupdict()
        if mdict['weighttype'] == 'POUNDS':
            try:
                roundtype = mdict['roundtype']
            except KeyError:
                roundtype = None

            #round weight gain by default
            if roundtype == 'EXACT':
                roundgain = False
            else:
                roundgain = True

            r = weightgain.getweightgain(gaintype=mdict['gaintype'], roundgain=roundgain)['pounds']

        elif mdict['weighttype'] == 'WEIGHT':
            try:
                try:
                    roundtype = mdict['roundtype']
                except KeyError:
                    roundtype = None

                #do not round actual weight by default
                if roundtype == 'ROUND':
                    roundweight = True
                else:
                    roundweight = False

                i = int(mdict['character']) - 1
                startweight = characters[i]['startweight']

                r = weightgain.getweightgain(gaintype=mdict['gaintype'], startweight=startweight, roundweight=roundweight)['weight']
            except TypeError:
                r = 'ERROR- ' + match.group(0) + 'has no character number assigned'

        replacementlist.append((match.group(0), str(r))) #duplicates are ok since will replace in order

    return replacementlist





def replacesynonyms(string):
    prompt.log('REPLACE SYNONYMS', string)
    s = string

    p = re.compile(r'\[([^{}\|\[\]]+)\]', re.IGNORECASE)
    matches = re.finditer(p, s)

    synonymdict = {}

    for match in matches:
        word = match.group(1)
        prompt.log('word',word)
        prompt.log('match group 0', match.group(0))
        try:
            s = s.replace(match.group(0), next(synonymdict[word]), 1)
        except KeyError:
            synonymdict[word] = getsynonym(word)
            s = s.replace(match.group(0), next(synonymdict[word]), 1)
        # prompt.log(next(synonymdict[word]))
        prompt.log('s',s)

    return s

#-------------------------------------------------------------

def replacegenderedchoice(string, characters):
    """ Replaces [1|man|woman] choices in string
        and returns string """

    s = string
    # p = re.compile(r'\[\s*(?P<character>\d)\s*\|\s*(?P<HE>[^|]*)\s*\|\s*(?P<SHE>[^\[\]]*)\s*\]')
    p = re.compile(r'\[\s*(?P<character>\d)\s*\|\s*(?P<HE>[^|{}]*)\s*\|\s*(?P<SHE>[^\[\]{}]*)\s*\]')
    matches = re.finditer(p, string)

    for match in matches:
        mdict = match.groupdict()

        i = int(mdict['character']) - 1
        pronoun = characters[i]['pronoun']
        r = mdict[pronoun]
        s = s.replace(match.group(0), str(r))

    return s

def replacesinglechoice(string):
    """ Randomly chooses whether to display {singlechoice} or not
        for all {singlechoice} in string
        Returns string """

    s = string
    p = re.compile(r'{([^\|{}\[\]]*)}')

    matches = re.finditer(p,s)

    for match in matches:
        choice = match.group(1)
        r = random.choice([choice, ''])
        s = s.replace(match.group(0), r)

    return s

def replacemultiplechoice(string):
    """ Randomly chooses which choice in {multiple|choice} to display
        for all {multiplechoice} in string
        Loops until all embedded
        {multiple{choice|choices}|multiple|choice} are resolved
        Returns string """

    s = string
    searchstring = r'(?P<replace>{(?P<g0>[^\|{}\[\]]*)(\|\||\|)((?P<g1>[^\|{}\[\]\[\]]*)(\|\||\|))?((?P<g2>[^\|{}\[\]]*)(\|\||\|))?((?P<g3>[^\|{}\[\]]*)(\|\||\|))?((?P<g4>[^\|{}\[\]]*)(\|\||\|))?((?P<g5>[^\|{}\[\]]*)(\|\||\|))?((?P<g6>[^\|{}\[\]]*)(\|\||\|))?((?P<g7>[^\|{}\[\]]*)(\|\||\|))?((?P<g8>[^\|{}\[\]]*)(\|\||\|))?(?P<g9>[^\|{}\[\]]*)})'

    i = 5 #i-2 = number of nested {} inside of outside {}
    for _ in range(i):
        prefix = n_chars(r'{.*', i-1)
        suffix = n_chars(r'.*}', i-1)
        newsearchstring = prefix + searchstring + suffix
        p = re.compile(newsearchstring)

        w = 0
        while True:
            match = p.search(s)
            if match == None:
                break
            s = replacemultiplechoicematch(s, match)
            w = w + 1
            if w > 50:
                prompt.log('!! infinite loop', match)
                break
        i = i - 1

    return s

def replacemultiplechoicematch(string, match):
    """ Accessory function for replacemultiplechoice()
        Randomly selects choice from match dictionary
        Returns string """

    s = string

    mdict = match.groupdict()
    mdictkeys = [x for x in mdict.keys() if 'g' in x and mdict[x] != None]

    k = random.choice(mdictkeys)
    r = mdict[k]

    s = s.replace(mdict['replace'], str(r))

    return s


def replacerandomint(string):
    """ Randomly chooses integer between [a:b]
        Returns string """

    s = string
    p = re.compile(r'\[\s*(?P<num1>\d+)\s*:\s*(?P<num2>\d+)\s*\]')
    matches = re.finditer(p,s)

    for match in matches:
        mdict = match.groupdict()
        intrange = sorted([int(mdict['num1']), int(mdict['num2'])])
        r = random.randint(intrange[0], intrange[1])

        s = s.replace(match.group(0), str(r))

    return s



#-------------------------------------------------------------

def replacetextfromlist(plot, searchreplacelist, optionfields=False, wrapper='', loop=False):
    """ Replaces the tuples (search,replace) in searchreplacelist in
        the object plot's textfields
        Returns plot object """

    w = 0

    while True:
        itemreplaced = False
        for (searchstring, replacestring) in searchreplacelist:
            plot, replacementmade = searchreplacetext(plot, searchstring=searchstring, replacestring=replacestring, wrapper=wrapper, optionfields=optionfields)
            if replacementmade:
                itemreplaced = True

        w = w + 1
        if loop == False or itemreplaced == False or w > 25:
            break

    return plot

def searchreplacetext(plot, searchstring='', replacestring='', optionfields=False, wrapper=''):
    """ Replaces searchstring/replacestring in the object
        plot's textfields or optionfields
        Returns plot object and if replacement was made (for purpose of loops) """

    if optionfields:
        textfieldnames = plot.getoptionfieldnames()
    else:
        textfieldnames = plot.gettextfieldnames()

    searchstring = encloseinwrapper(searchstring, wrapper)
    replacementmade = False

    for textfieldname in textfieldnames:
        s = getattr(plot, textfieldname)
        if searchstring in s:
            s = s.replace(searchstring, replacestring)
            setattr(plot, textfieldname, s)
            replacementmade = True

    return (plot, replacementmade)


def funcreplacetext(plot, func, optionfields=False, extraArgs=[]):
    """ Replaces text in the object plot's textfields or optionfields
        using func function to do replacement
        Returns plot """

    if optionfields:
        textfieldnames = plot.getoptionfieldnames()
    else:
        textfieldnames = plot.gettextfieldnames()

    for textfieldname in textfieldnames:
        oldstring = getattr(plot, textfieldname)
        newstring = func(oldstring, *extraArgs)
        setattr(plot, textfieldname, newstring)
    return plot






#-------------------------------------------------------------

def removeduplicatepunctuation(string):
    s = string

    # remove extra whitespace
    # space between last word and end of sentence
    p = re.compile(r'(\s+)([.,?!])')
    s = re.sub(p, r"\2", s)
    # multiple spaces in row
    p = re.compile(r'[[:blank:]]{2,}')
    s = re.sub(p,' ',s)
    # whitespace after beginning quote
    p = re.compile(r'(\")([[:blank:]]+)([^\"\n]*\")')
    s = re.sub(p, r"\1\3", s)
    # whitespace before end quote
    p = re.compile(r'(\"[^\"\n]*)([[:blank:]]+)(\")')
    s = re.sub(p, r"\1\3", s)

    #remove duplicates ('..')
    p = re.compile(r'([\",.!?])\1{2,}')
    s = re.sub(p, r'\1', s)

    # manually remove duplicate punctuation
    # some of these might happen intentionally
    # for convenience in prompt writing
    duplicatepunctuation = [
        ['..', '.'],
        ['. .', '.'],
        ['.,', '.'],
        ['. ,', '.'],
        [',.', '.'],
        [', .', '.'],
        [',,', ','],
        ['?.', '?'],
        ['?,', '?'],
        ['".', '"'],
        ['",', '"'],
    ]
    for (searchstring, replacestring) in duplicatepunctuation:
        s = s.replace(searchstring, replacestring)

    s = s.lstrip(',')
    s = s.lstrip('.')
    s = s.lstrip('?')
    s = s.lstrip('!')
    s = s.strip()


    return s


def capitalizenewsentences(string):
    """
        Does not work if there is html markup (i.e. <p> tags) """

    s = string

    # prompt.log('capitalizenewsentences')
    # prompt.log('old text:', repr(s))

    # Capitalize first letter of string
    p = re.compile(r'^\w')
    s = re.sub(p, lambda x: x.group(0).upper(), s)

    # Capitalize words after . ? !
    # sometimes there are spaces that aren't captured as spaces
    # so not using \s
    p = re.compile(r'(?<=[\.\?!])(?:[^\w\<\>/\"]+?)(\w)')
    s = re.sub(p, lambda x: x.group(0).upper(), s)

    # Capitalize letters after quotes
    p = re.compile(r'(?<=\")(\w)')
    s = re.sub(p, lambda x: x.group(0).upper(), s)

    # prompt.log('new text:', s)

    return s

#-------------------------------------------------------------

def encloseinwrapper(string, wrapper):
    """ Encloses 'string' in wrapper '[]'
        and returns '[string]' """

    try:
        s = wrapper[0] + string + wrapper[1]
    except IndexError:
        s = string
    return s


def n_chars(char, n):
    """ Creates string composed of repeat of same character
        char = '{', n = 3 -> s = '{{{'
        Returns string """

    s = ''
    if n > 0:
        for _ in range(n):
            s = s + char
    return s

#-------------------------------------------------------------


def getsynonym(word):
    """ Generator that yields synonym from Synonyms object
        If word exists, returns synonym; otherwise returns 'word'
        Favors common synonyms (*) by factor
        of settings.COMMON_SYNONYM_MULTIPLIER """

    try:
        # synonyms = Synonyms.objects.get(word=word).synonyms.split('\r\n')
        synonyms = Synonyms.objects.get(Q(word__iexact = word) | Q(description__iexact = word))
        synonyms = synonyms.synonyms.split('\r\n')

    except Synonyms.DoesNotExist:
        while True:
            yield word

    commonsynonyms = []
    uncommonsynonyms = []

    for synonym in synonyms:
        if synonym == '':
            continue
        if '*' in synonym:
            commonsynonyms.append(synonym.strip('*'))
        else:
            uncommonsynonyms.append(synonym)

    allsynonyms = []

    for _ in range(settings.COMMON_SYNONYM_MULTIPLIER):
        allsynonyms.extend(commonsynonyms)

    allsynonyms.extend(uncommonsynonyms)

    while True:
        random.shuffle(allsynonyms)
        for synonym in allsynonyms:
            yield synonym

def getalltextfieldtext(plot, optionfields=False):
    """ Returns list of strings of names of
        object plot's textfields or option fields """

    s = ''
    if optionfields:
        textfieldnames = plot.getoptionfieldnames()
    else:
        textfieldnames = plot.gettextfieldnames()
    for textfieldname in textfieldnames:
        s += getattr(plot, textfieldname)
    return s
























