import random
from collections import OrderedDict

# GAIN_TYPES = OrderedDict(
#     'ANY':{
#         'floor':15,
#         'ceil':175,
#         'factor':200,
#     },
#     'ANYNOTSMALL':{
#         'floor':30,
#         'ceil':175,
#         'factor':200,
#     },
#     'SMALL':{
#         'floor':7,
#         'ceil':25,
#         'factor':100,
#     },
#     'SMALLMEDIUM':{
#         'floor':15,
#         'ceil':30,
#         'factor':80,
#     },
#     'MEDIUM':{
#         'floor':25,
#         'ceil':50,
#         'factor':200,
#     },
#     'MEDIUMLARGE':{
#         'floor':30,
#         'ceil':110,
#         'factor':200,
#     },
#     'LARGE':{
#         'floor':50,
#         'ceil':125,
#         'factor':300,
#     },
#     'LARGEXLARGE':{
#         'floor':50,
#         'ceil':300,
#         'factor':300,
#     },
#     'XLARGE':{
#         'floor':100,
#         'ceil':300,
#         'factor':300,
#     },
# )

GAIN_TYPES = OrderedDict()

GAIN_TYPES['ANY'] = {
	'floor':15,
	'ceil':175,
	'factor':200,
}
GAIN_TYPES['ANYNOTSMALL'] = {
	'floor':30,
	'ceil':175,
	'factor':200,
}
GAIN_TYPES['SMALL'] = {
	'floor':7,
	'ceil':25,
	'factor':100,
}
GAIN_TYPES['SMALLMEDIUM'] = {
	'floor':15,
	'ceil':30,
	'factor':80,
}
GAIN_TYPES['MEDIUM'] = {
	'floor':25,
	'ceil':50,
	'factor':200,
}
GAIN_TYPES['MEDIUMLARGE'] = {
	'floor':30,
	'ceil':110,
	'factor':200,
}
GAIN_TYPES['LARGE'] = {
	'floor':50,
	'ceil':125,
	'factor':300,
}
GAIN_TYPES['LARGEXLARGE'] = {
	'floor':50,
	'ceil':300,
	'factor':300,
}
GAIN_TYPES['XLARGE'] = {
	'floor':100,
	'ceil':300,
	'factor':300,
}

def getweightgain(startweight=150,gaintype='ANY',floor=10, ceil=200,roundgain=True,roundweight=False):
    # factor = 200
    weightdifference = 0
    a = 2
    b = 5

    floor = GAIN_TYPES[gaintype]['floor']
    ceil = GAIN_TYPES[gaintype]['ceil']
    factor = GAIN_TYPES[gaintype]['factor']

    while weightdifference <= floor or weightdifference >= ceil:
        weightdifference = random.betavariate(a,b)
        weightdifference = weightdifference * factor

    weightgained = weightdifference
    newweight = int(startweight) + weightdifference

    if roundgain:
        if weightgained < 50:
            weightgained = roundtobase(weightgained,5)
        elif weightgained < 100:
            weightgained = roundtobase(weightgained,10)
        else:
            weightgained = roundtobase(weightgained,25)
    else:
        weightgained = int(weightgained)

    if roundweight:
        if newweight < 200:
            newweight = roundtobase(newweight,5)
        elif newweight < 275:
            newweight = roundtobase(newweight,10)
        else: # newweight < 200:
            newweight = roundtobase(newweight,25)

    else:
        newweight = int(newweight)

    out = {
        'pounds' : weightgained,
        'weight' : newweight,
        }

    return out



    # print('he gains ' + str(weightgained) + ' pounds and now weighs ' + str(newweight) + ' pounds')


def roundtobase(x, roundto=5):
    return int(roundto * round(float(x)/roundto))